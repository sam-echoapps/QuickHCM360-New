define(['ojs/ojcore', 'knockout', 'jquery', 'appController', "ojs/ojmodulerouter-adapter", 'ojs/ojtranslation', 'ojs/ojconverter-number', 'ojs/ojarraydataprovider',
    'ojs/ojmasonrylayout', 'ojs/ojbutton', 'ojs/ojoption', 'ojs/ojlabel', 'ojs/ojactioncard'],
    function (oj, ko, $, app, ModuleRouterAdapter, Translations, NumberConverter, ArrayDataProvider) {
        class MonitorViewModel {
            constructor(args) {
                var self = this;
                self.ExtName = ko.observable();
                self.PmpName = ko.observable();
                self.RepName = ko.observable();

                self.ExtData1 = ko.observableArray([]);
                self.PmpData1 = ko.observableArray([]);
                self.RepData1 = ko.observableArray([]);

                self.styleExt = ko.observable();
                self.stylePmp = ko.observable();
                self.styleRep = ko.observable();
                self.ExtATCSN = ko.observable();
                self.ExtAFTERCSN = ko.observable();

                self.RepATCSN = ko.observable();
                self.RepAFTERCSN = ko.observable();

                self.decimalHalfDownConverter =
                    new NumberConverter.IntlNumberConverter({
                        style: 'decimal',
                        roundingMode: 'HALF_DOWN',
                        maximumFractionDigits: 0,
                        useGrouping: false
                    });


                function monitorAll() {
                    $.ajax({
                        url: "http://192.168.0.11:8080/ggmonitorall",
                        type: 'GET',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            self.ExtData1([]);
                            self.PmpData1([]);
                            self.RepData1([]);
                            for (var i = 0; i < data[0].length; i++) {
                                if (data[0][i].extstat == 'ABENDED') {
                                    self.styleExt = { "background-color": "IndianRed" };
                                    self.ExtData1.push({ ExtName: data[0][i].extname, ExtStat: data[0][i].extstat, ExtLag: data[0][i].extlag, ExtChkLag: data[0][i].extchklag });

                                } else if (data[0][i].extstat == 'STOPPED') {

                                    self.styleExt = { "background-color": "Chocolate" };
                                    self.ExtData1.push({ ExtName: data[0][i].extname, ExtStat: data[0][i].extstat, ExtLag: data[0][i].extlag, ExtChkLag: data[0][i].extchklag });

                                } else if (data[0][i].extstat == 'RUNNING') {
                                    self.styleExt = { "background-color": "ForestGreen" };
                                    self.ExtData1.push({ ExtName: data[0][i].extname, ExtStat: data[0][i].extstat, ExtLag: data[0][i].extlag, ExtChkLag: data[0][i].extchklag });
                                }
                                if (data[0][i].pmpstat == 'ABENDED') {

                                    self.stylePmp = { "background-color": "IndianRed" };
                                    self.PmpData1.push({ PmpName: data[0][i].pmpname, PmpStat: data[0][i].pmpstat, PmpLag: data[0][i].pmplag, PmpChkLag: data[0][i].pmpchklag });

                                } else if (data[0][i].pmpstat == 'STOPPED') {

                                    self.stylePmp = { "background-color": "Chocolate" };
                                    self.PmpData1.push({ PmpName: data[0][i].pmpname, PmpStat: data[0][i].pmpstat, PmpLag: data[0][i].pmplag, PmpChkLag: data[0][i].pmpchklag });

                                } else if (data[0][i].pmpstat == 'RUNNING') {

                                    self.stylePmp = { "background-color": "ForestGreen" };
                                    self.PmpData1.push({ PmpName: data[0][i].pmpname, PmpStat: data[0][i].pmpstat, PmpLag: data[0][i].pmplag, PmpChkLag: data[0][i].pmpchklag });
                                }

                                if (data[0][i].repstat == 'ABENDED') {
                                    self.styleRep = { "background-color": "IndianRed" };
                                    self.RepData1.push({ RepName: data[0][i].repname, RepStat: data[0][i].repstat, RepLag: data[0][i].replag, RepChkLag: data[0][i].repchklag });
                                } else if (data[0][i].repstat == 'STOPPED') {

                                    self.styleRep = { "background-color": "Chocolate" };
                                    self.RepData1.push({ RepName: data[0][i].repname, RepStat: data[0][i].repstat, RepLag: data[0][i].replag, RepChkLag: data[0][i].repchklag });
                                } else if (data[0][i].repstat == 'RUNNING') {
                                    self.styleRep = { "background-color": "ForestGreen" };
                                    self.RepData1.push({ RepName: data[0][i].repname, RepStat: data[0][i].repstat, RepLag: data[0][i].replag, RepChkLag: data[0][i].repchklag });
                                }

                            }

                            console.log(self);
                            return self;
                        }
                    })

                }




                self.extRefresh = function (event, data) {
                    monitorAll();
                }


                self.processDataDP = new ArrayDataProvider(self.ExtData1, { idAttribute: 'ExtName' });

                self.args = args;
                // Create a child router with one default path
                self.router = self.args.parentRouter;

                //            self.router =  context.parentRouter;
                this.logMsg = ko.observable("none");
                self.actionHandler = (event) => {
                    self.router.go({ path: 'processMon', params: { process: event.currentTarget.id } })
                };

                self.handledExtCollapse = false;
                self.handledPmpCollapse = false;
                self.handledRepCollapse = false;

                var closestByClass = function (el, className) {
                    while (!el.classList.contains(className)) {
                        // Increment the loop to the parent node
                        el = el.parentNode;
                        if (!el) {
                            return null;
                        }
                    }
                    return el;
                };

                // This listener is called when the resize button in the tile
                // is clicked.
                self.ExtResizeTile = function (event, current) {
                    var target = event.target;

                    var tile = closestByClass(target, 'ext-tile');
                    var masonryLayout = closestByClass(tile, 'oj-masonrylayout');
                    // get the data for the tile, which will be an item in the
                    // chemicals array defined above
                    var data = current.data;
                    self.ExtName = current.data.ExtName;
                    masonryLayout.resizeTile(
                        '#' + tile.getAttribute('id'),
                        data.expanded() ? data.collapsedSizeClass : data.expandedSizeClass);
                };

                // This listener is called before the tile is resized  for the Extract
                self.ExtHandleBeforeResize = function (event) {
                    var tile = event.detail.tile;
                    var context = ko.contextFor(tile);
                    var data = context.$current.data;
                    self.ExtName = context.$current.data.ExtName;
                    // If the tile is being collapsed, hide the additional
                    // expanded content before the tile is resized.
                    if (data.expanded()) {
                        data.expanded(false);
                        // Remember that this resize is a collapse so that the
                        // "resize" event listener called after the tile is resized
                        // does not also try to handle the operation.
                        self.handledExtCollapse = true;
                    }
                };

                // This listener is called after the tile is resized  for the Extract
                self.ExtHandleResize = function (event) {
                    // Only handle the event if the tile is being expanded.
                    if (!self.handledExtCollapse) {
                        var tile = event.detail.tile;
                        // get the ko binding context for the tile DOM element
                        var context = ko.contextFor(tile);
                        // get the data for the tile, which will be an item in the
                        // chemicals array defined above
                        var data = context.$current.data;

                        self.ExtName = context.$current.data.ExtName;
                        // If the tile is being expanded, show the additional
                        // content after the tile is resized.
                        if (!data.expanded()) {
                            data.expanded(true);
                        }
                    }
                    // Reset the flag for the next resize.
                    self.handledExtCollapse = false;
                };


                // This listener is called when the resize button in the tile
                // is clicked.
                self.PmpResizeTile = function (event, current) {
                    var target = event.target;

                    var tile = closestByClass(target, 'pmp-tile');
                    var masonryLayout = closestByClass(tile, 'oj-masonrylayout');
                    // get the data for the tile, which will be an item in the
                    // chemicals array defined above
                    var data = current.data;
                    self.PmpName = current.data.PmpName;
                    masonryLayout.resizeTile(
                        '#' + tile.getAttribute('id'),
                        data.expanded() ? data.collapsedSizeClass : data.expandedSizeClass);
                };

                // This listener is called before the tile is resized for thre Pump.
                self.PmpHandleBeforeResize = function (event) {
                    var tile = event.detail.tile;
                    var context = ko.contextFor(tile);
                    var data = context.$current.data;
                    self.PmpName = context.$current.data.PmpName;
                    // If the tile is being collapsed, hide the additional
                    // expanded content before the tile is resized.
                    if (data.expanded()) {
                        data.expanded(false);
                        // Remember that this resize is a collapse so that the
                        // "resize" event listener called after the tile is resized
                        // does not also try to handle the operation.
                        self.handledPmpCollapse = true;
                    }
                };

                // This listener is called after the tile is resized  for the Pump
                self.PmpHandleResize = function (event) {
                    // Only handle the event if the tile is being expanded.
                    if (!self.handledPmpCollapse) {
                        var tile = event.detail.tile;
                        // get the ko binding context for the tile DOM element
                        var context = ko.contextFor(tile);
                        // get the data for the tile, which will be an item in the
                        // chemicals array defined above
                        var data = context.$current.data;

                        self.PmpName = context.$current.data.PmpName;
                        // If the tile is being expanded, show the additional
                        // content after the tile is resized.
                        if (!data.expanded()) {
                            data.expanded(true);
                        }
                    }
                    // Reset the flag for the next resize.
                    self.handledPmpCollapse = false;
                };

                self.RepResizeTile = function (event, current) {
                    var target = event.target;

                    var tile = closestByClass(target, 'rep-tile');
                    var masonryLayout = closestByClass(tile, 'oj-masonrylayout');
                    // get the data for the tile, which will be an item in the
                    // chemicals array defined above
                    var data = current.data;
                    self.RepName = current.data.RepName;
                    masonryLayout.resizeTile(
                        '#' + tile.getAttribute('id'),
                        data.expanded() ? data.collapsedSizeClass : data.expandedSizeClass);
                };

                // This listener is called before the tile is resized for Replicat.
                self.RepHandleBeforeResize = function (event) {
                    var tile = event.detail.tile;
                    var context = ko.contextFor(tile);
                    var data = context.$current.data;
                    self.RepName = context.$current.data.RepName;
                    // If the tile is being collapsed, hide the additional
                    // expanded content before the tile is resized.
                    if (data.expanded()) {
                        data.expanded(false);
                        // Remember that this resize is a collapse so that the
                        // "resize" event listener called after the tile is resized
                        // does not also try to handle the operation.
                        self.handledRepCollapse = true;
                    }
                };

                // This listener is called after the tile is resized for the Replicat.
                self.RepHandleResize = function (event) {
                    // Only handle the event if the tile is being expanded.
                    if (!self.handledRepCollapse) {
                        var tile = event.detail.tile;
                        // get the ko binding context for the tile DOM element
                        var context = ko.contextFor(tile);
                        // get the data for the tile, which will be an item in the
                        // chemicals array defined above
                        var data = context.$current.data;

                        self.RepName = context.$current.data.RepName;
                        // If the tile is being expanded, show the additional
                        // content after the tile is resized.
                        if (!data.expanded()) {
                            data.expanded(true);
                        }
                    }
                    // Reset the flag for the next resize.
                    self.handledRepCollapse = false;
                };

                self.getExtTileId = function (index) {
                    return 'ext-tile' + (index + 1);
                };

                self.getExtLabelId = function (index) {
                    return 'ext-label' + (index + 1);
                };

                self.getExtButtonId = function (index) {
                    return 'ext-resizeButton' + (index + 1);
                };

                self.getExtButtonLabelledBy = function (index) {
                    return self.getExtButtonId(index) + ' ' + self.getExtLabelId(index);
                };

                self.getExtButtonLabel = function (data) {
                    return data.expanded() ?
                        Translations.getTranslatedString(
                            'oj-panel.labelAccButtonCollapse') :
                        Translations.getTranslatedString(
                            'oj-panel.labelAccButtonExpand');
                };

                self.getExtButtonIcon = function (data) {
                    return {
                        'oj-panel-expand-icon': !data.expanded(),
                        'oj-panel-collapse-icon': data.expanded()
                    };
                };


                //Pump 

                self.getPmpTileId = function (index) {
                    return 'pmp-tile' + (index + 1);
                };

                self.getPmpLabelId = function (index) {
                    return 'pmp-label' + (index + 1);
                };

                self.getPmpButtonId = function (index) {
                    return 'pmp-resizeButton' + (index + 1);
                };

                self.getPmpButtonLabelledBy = function (index) {
                    return self.getPmpButtonId(index) + ' ' + self.getPmpLabelId(index);
                };

                self.getPmpButtonLabel = function (data) {
                    return data.expanded() ?
                        Translations.getTranslatedString(
                            'oj-panel.labelAccButtonCollapse') :
                        Translations.getTranslatedString(
                            'oj-panel.labelAccButtonExpand');
                };

                self.getPmpButtonIcon = function (data) {
                    return {
                        'oj-panel-expand-icon': !data.expanded(),
                        'oj-panel-collapse-icon': data.expanded()
                    };
                };

                self.getRepTileId = function (index) {
                    return 'rep-tile' + (index + 1);
                };

                self.getRepLabelId = function (index) {
                    return 'rep-label' + (index + 1);
                };

                self.getRepButtonId = function (index) {
                    return 'rep-resizeButton' + (index + 1);
                };

                self.getRepButtonLabelledBy = function (index) {
                    return self.getRepButtonId(index) + ' ' + self.getRepLabelId(index);
                };

                self.getRepButtonLabel = function (data) {
                    return data.expanded() ?
                        Translations.getTranslatedString(
                            'oj-panel.labelAccButtonCollapse') :
                        Translations.getTranslatedString(
                            'oj-panel.labelAccButtonExpand');
                };

                self.getRepButtonIcon = function (data) {
                    return {
                        'oj-panel-expand-icon': !data.expanded(),
                        'oj-panel-collapse-icon': data.expanded()
                    };
                };



                self.connected = function () {
                    if (sessionStorage.getItem("userName") == null) {
                        self.router.go({path : 'signin'});
                    }
                    else {
                        app.onAppSuccess();
                        monitorAll();
                    }
                }

                /**
                 * Optional ViewModel method invoked after the View is disconnected from the DOM.
                 */
                self.disconnected = function () {
                    // Implement if needed
                };

                /**
                 * Optional ViewModel method invoked after transition to the new View is complete.
                 * That includes any possible animation between the old and the new View.
                 */
                self.transitionCompleted = function () {



                };

            }
            /*
             * Returns a constructor for the ViewModel so that the ViewModel is constructed
             * each time the view is displayed.  Return an instance of the ViewModel if
             * only one instance of the ViewModel is needed.
             */

        }
        return MonitorViewModel;
    }
);

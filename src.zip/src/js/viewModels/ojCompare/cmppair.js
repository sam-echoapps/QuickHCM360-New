
define(['ojs/ojcore', 'knockout', 'jquery','appController' ,'ojs/ojpagingdataproviderview', 'ojs/ojkeyset', 'ojs/ojknockout', 'ojs/ojtrain', 'ojs/ojradioset', 'ojs/ojbutton', 'ojs/ojlabelvalue', 'ojs/ojdatetimepicker', 'ojs/ojlabel', 'ojs/ojformlayout', 'ojs/ojinputtext', 'ojs/ojselectsingle', 'ojs/ojinputnumber', 'ojs/ojvalidationgroup', 'ojs/ojselectcombobox', 'ojs/ojdialog', 'ojs/ojtable', 'ojs/ojpagingcontrol'],
        function (oj, ko, $, app, PagingDataProviderView, keySet) {

            function CompGrpViewModel() {
                var self = this;

                this.selectedStepValue = ko.observable('stp1');
                this.selectedStepLabel = ko.observable('Extract Type');
                this.selectedStepFormLabel = ko.observable('Extract Type');

                this.stepArray =
                        ko.observableArray([
                            {label: 'Select Collate Group', id: 'stp1'},
                            {label: 'Configure Collate Pair', id: 'stp2'},
                            {label: 'Validate Collate Pair ', id: 'stp3'},
                            {label: 'Configire Collate Job ', id: 'stp4'}                            
                        ]);

                self.previousStep = function () {
                    var train = document.getElementById('train');
                    var prev = train.getPreviousSelectableStep();
                    if (prev != null) {
                        this.selectedStepValue(prev);
                        this.selectedStepLabel(train.getStep(prev).label);
                    }
                }.bind(this);

                self.nextStep = function () {
                    var train = document.getElementById('train');
                    var next = train.getNextSelectableStep();
                    if (next != null) {
                        this.selectedStepValue(next);
                        this.selectedStepLabel(train.getStep(next).label);
                    }
                }.bind(this);

                this.updateLabelText = function (event) {
                    var train = document.getElementById("train");
                    this.selectedStepLabel(train.getStep(event.detail.value).label);
                    if (train.getStep(event.detail.value).id == "stp2") {
                        this.selectedStepFormLabel('Extract Details');
                        this.isFormReadonly(false);
                    } else if (train.getStep(event.detail.value).id == "stp1") {
                        this.selectedStepFormLabel('Extract Type');
                        this.isFormReadonly(false);
                    } else {
                        this.selectedStepFormLabel('');
                        this.isFormReadonly(true);
                    }
                }.bind(this);


                this.isRequired = ko.observable(true);
                this.checkboxValues = ko.observableArray(['required', 'helpSource', 'helpDef']);

                this.isRequired = ko.computed(function () {
                    return this.checkboxValues.indexOf('required') !== -1;
                }.bind(this));
                this.helpDef = ko.computed(function () {
                    return (this.checkboxValues.indexOf('helpDef') !== -1) ? this._HELP_DEF : null;
                }.bind(this));
                this.helpSource = ko.computed(function () {
                    return (this.checkboxValues.indexOf('helpSource') !== -1) ? this._HELP_SOURCE : null;
                }.bind(this));

                this.isFormReadonly = ko.observable(false);

                self.CreateConnMsg = ko.observable();
                self.srcconnName = ko.observable();
                self.tgtconnName = ko.observable();
                self.srcSchemaName = ko.observable();
                self.tgtSchemaName = ko.observable();
                self.uName = ko.observable();
                self.uPasswd = ko.observable();
                self.SIP = ko.observable();
                self.PKey = ko.observable();
                self.grpNameList = ko.observableArray([]);
                self.srcschemaNameList = ko.observableArray([]);
                self.tgtschemaNameList = ko.observableArray([]);
                self.grpName = ko.observable();
                self.srctableNameList = ko.observableArray([]);
                self.tgttableNameList = ko.observableArray([]);

                self.cmpPairList = ko.observableArray([]);
                
                self.jobName  = ko.observable();
                self.selectgrpName = ko.observable();



                function grpList() {
                    self.grpNameList([]);
                    $.ajax({
                        url: "//supplog",
                        type: 'GET',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {

                            for (var i = 0; i < data[3].length; i++) {

                                self.grpNameList.push({label: data[3][i].GRPNAME, value: data[3][i].GRPNAME});
                            }

                            console.log(self);
                            return self;
                        }

                    })

                }

                grpList();

                self.grplistDP = new oj.ArrayDataProvider(self.grpNameList, {keyAttributes: 'value'});
                
                                self.grpPairArray = [{headerText: 'Pair Name ',
                        field: 'Pair_Name'},
                {headerText: 'Source Schema',
                        field: 'Src_Schema'},
                {headerText: 'Source Table Name',
                        field: 'Src_Tab'},
                {headerText: 'Target Schema',
                        field: 'Tgt_Schema'},
                {headerText: 'Target Table Name',
                        field: 'Tgt_Tab'}];


                self.grpSelectionChanged = function (data, event) {
                    self.srcschemaNameList([]);
                    self.tgtschemaNameList([]);
                    self.srcconnName('');
                    self.tgtconnName('');
                    $.ajax({
                        url: "//schemalist",
                        type: 'POST',
                        data: JSON.stringify({
                            grpName: self.grpName()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {

                            for (var i = 0; i < data[0].length; i++) {
                                self.srcschemaNameList.push({label: data[0][i].OWNER, value: data[0][i].OWNER});

                            }

                            for (var i = 0; i < data[1].length; i++) {
                                self.tgtschemaNameList.push({label: data[1][i].OWNER, value: data[1][i].OWNER});

                            }

                            self.srcconnName(data[2]);
                            self.tgtconnName(data[3]);

                            for (var i = 0; i < data[4].length; i++) {
                                self.cmpPairList.push({Pair_Name: data[4][i].PAIRNAME,Src_Schema:data[4][i].SRCSCHEMANAME,Src_Tab:data[4][i].SRCTABNAME,Tgt_Schema:data[4][i].TGTSCHEMANAME,Tgt_Tab:data[4][i].TGTTABNAME});

                            }
                            return self;
                        }

                    })
                }


                self.srcschemalistDP = new oj.ArrayDataProvider(self.srcschemaNameList, {keyAttributes: 'value'});
                self.tgtschemalistDP = new oj.ArrayDataProvider(self.tgtschemaNameList, {keyAttributes: 'value'});
                self.cmpPairListDP = new oj.ArrayDataProvider(self.cmpPairList, {keyAttributes: 'Pair_Name'});



                self.srcschemaSelectionChanged = function (data, event) {
                    self.srctableNameList([]);
                    $.ajax({
                        url: "//tablelist",
                        type: 'POST',
                        data: JSON.stringify({
                            connName: self.srcconnName(),
                            schemaName: self.srcSchemaName()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {

                            for (var i = 0; i < data[0].length; i++) {
                                self.srctableNameList.push({Tab_Name: data[0][i].TABLE_NAME});
                            }
                            return self;
                        }

                    })
                }


                self.srctablelistDP = new oj.ArrayDataProvider(self.srctableNameList, {keyAttributes: 'Tab_Name'});

                self.allcolumnArray = [{headerText: 'Table Name ',
                        field: 'Tab_Name'}];




                self.tgtschemaSelectionChanged = function (data, event) {
                    self.tgttableNameList([]);
                    $.ajax({
                        url: "//tablelist",
                        type: 'POST',
                        data: JSON.stringify({
                            connName: self.tgtconnName(),
                            schemaName: self.tgtSchemaName()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {

                            for (var i = 0; i < data[0].length; i++) {
                                self.tgttableNameList.push({Tab_Name: data[0][i].TABLE_NAME});
                            }
                            return self;
                        }

                    })
                }


                self.tgttablelistDP = new oj.ArrayDataProvider(self.tgttableNameList, {keyAttributes: 'Tab_Name'});

                self.allcolumnArray = [{headerText: 'Table Name ',
                        field: 'Tab_Name'}];


                this.srcItems = ko.observable({row: new keySet.KeySetImpl(), column: new keySet.KeySetImpl()});
                this.srcInfo = ko.observable('');
                this.srcSelectionMode = ko.observable({row: 'single', column: 'none'});

                this.srcSelectionMode.subscribe(function (newValue) {
                    // Reset selected Items on selection mode change.
                    this.srcItems({row: new keySet.KeySetImpl(), column: new keySet.KeySetImpl()});
                }.bind(this));

                this.srcChangedListener = function (event) {
                    var selectionText = '';

                    if (event.detail.value.row.isAddAll()) {
                        var iterator = event.detail.value.row.deletedValues();
                        iterator.forEach(function (key) {
                            selectionText = selectionText.length === 0 ? key : selectionText + ', ' + key;
                        });

                        if (iterator.size > 0) {
                            selectionText = ' except ' + selectionText;
                        }
                        selectionText = 'Row Selection:\nAll rows are selected' + selectionText;
                    } else {
                        if (event.detail.value.row.values().size > 0) {
                            event.detail.value.row.values().forEach(function (key) {
                                selectionText += (selectionText.length === 0 ? key : ', ' + key);
                            });
                            selectionText = selectionText;
                        }
                        if (event.detail.value.column.values().size > 0) {
                            event.detail.value.column.values().forEach(function (key) {
                                selectionText += (selectionText.length === 0 ? key : ', ' + key);
                            });
                            selectionText = 'Column Selection:\nColumn Keys: ' + selectionText;
                        }
                    }
                    this.srcInfo(selectionText);
                }.bind(this);




                this.tgtItems = ko.observable({row: new keySet.KeySetImpl(), column: new keySet.KeySetImpl()});
                this.tgtInfo = ko.observable('');
                this.tgtSelectionMode = ko.observable({row: 'single', column: 'none'});

                this.tgtSelectionMode.subscribe(function (newValue) {
                    // Reset selected Items on selection mode change.
                    this.tgtItems({row: new keySet.KeySetImpl(), column: new keySet.KeySetImpl()});
                }.bind(this));

                this.tgtChangedListener = function (event) {
                    var selectionText = '';

                    if (event.detail.value.row.isAddAll()) {
                        var iterator = event.detail.value.row.deletedValues();
                        iterator.forEach(function (key) {
                            selectionText = selectionText.length === 0 ? key : selectionText + ', ' + key;
                        });

                        if (iterator.size > 0) {
                            selectionText = ' except ' + selectionText;
                        }
                        selectionText = 'Row Selection:\nAll rows are selected' + selectionText;
                    } else {
                        if (event.detail.value.row.values().size > 0) {
                            event.detail.value.row.values().forEach(function (key) {
                                selectionText += (selectionText.length === 0 ? key : ', ' + key);
                            });
                            selectionText = selectionText;
                        }
                        if (event.detail.value.column.values().size > 0) {
                            event.detail.value.column.values().forEach(function (key) {
                                selectionText += (selectionText.length === 0 ? key : ', ' + key);
                            });
                            selectionText = 'Column Selection:\nColumn Keys: ' + selectionText;
                        }
                    }
                    this.tgtInfo(selectionText);
                }.bind(this);

                self.AddCmpPairMsg = ko.observable();
                self.tmpCmpPairList = ko.observableArray([]);

                self.genCompPair = function (data, event) {
                    self.tmpCmpPairList([]);
                    $.ajax({
                        url: "//createpair",
                        type: 'POST',
                        data: JSON.stringify({
                            grpName: self.grpName(),
                            srcconnName : self.srcconnName(),
                            srcSchemaName: self.srcSchemaName(),
                            srcTabName: self.srcInfo(),
                            tgtconnName : self.tgtconnName(),
                            tgtSchemaName: self.tgtSchemaName(),
                            tgtTabName: self.tgtInfo()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#GenCmpPairDialog').open();
                            self.AddCmpPairMsg(data[0]);
                            for (var i = 0; i < data[1].length; i++) {
                                self.tmpCmpPairList.push({Pair_Name: data[1][i].PAIRNAME,Src_Schema:data[1][i].SRCSCHEMANAME,Src_Tab:data[1][i].SRCTABNAME,Tgt_Schema:data[1][i].TGTSCHEMANAME,Tgt_Tab:data[1][i].TGTTABNAME});
                            }
                            return self;
                        }

                    })
                }

                                self.tmpCmpPairListDP = new oj.ArrayDataProvider(self.tmpCmpPairList, {keyAttributes: 'Pair_Name'});


                this.pairItems = ko.observable({row: new keySet.KeySetImpl(), column: new keySet.KeySetImpl()});
                this.pairInfo = ko.observable('');
                this.pairSelectionMode = ko.observable({row: 'single', column: 'none'});

                this.pairSelectionMode.subscribe(function (newValue) {
                    // Reset selected Items on selection mode change.
                    this.pairItems({row: new keySet.KeySetImpl(), column: new keySet.KeySetImpl()});
                }.bind(this));

                this.pairChangedListener = function (event) {
                    var selectionText = '';

                    if (event.detail.value.row.isAddAll()) {
                        var iterator = event.detail.value.row.deletedValues();
                        iterator.forEach(function (key) {
                            selectionText = selectionText.length === 0 ? key : selectionText + ', ' + key;
                        });

                        if (iterator.size > 0) {
                            selectionText = ' except ' + selectionText;
                        }
                        selectionText = 'Row Selection:\nAll rows are selected' + selectionText;
                    } else {
                        if (event.detail.value.row.values().size > 0) {
                            event.detail.value.row.values().forEach(function (key) {
                                selectionText += (selectionText.length === 0 ? key : ', ' + key);
                            });
                            selectionText = selectionText;
                        }
                        if (event.detail.value.column.values().size > 0) {
                            event.detail.value.column.values().forEach(function (key) {
                                selectionText += (selectionText.length === 0 ? key : ', ' + key);
                            });
                            selectionText = 'Column Selection:\nColumn Keys: ' + selectionText;
                        }
                    }
                    this.pairInfo(selectionText);
                }.bind(this);



                self.GenCompKClose = function (event) {
                    document.querySelector('#GenCmpPairDialog').close();
                };

                self.validateCmpPairMsg = ko.observable();

                self.validatePair = function (data, event) {
                    $.ajax({
                        url: "//validatepair",
                        type: 'POST',
                        data: JSON.stringify({
                            pairName : self.pairInfo(),
                            grpName : self.grpName()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ValCmpPairDialog').open();
                            self.validateCmpPairMsg(data[0]);
                            return self;
                        }

                    })
                }

                self.ValidatePairOKClose = function (event) {
                    document.querySelector('#ValCmpPairDialog').close();
                    self.tmpCmpPairList([]);
                    
                };

             self.createCmpJobMsg = ko.observable();

                self.createCmpJob = function (data, event) {
                    $.ajax({
                        url: "http://192.168.0.11:8080/createjob",
                        type: 'POST',
                        data: JSON.stringify({
                            jobName : self.jobName(),
                            grpName : self.selectgrpName()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#createCmpJobDialog').open();
                            self.createCmpJobMsg(data[0]);
                            return self;
                        }

                    })
                }

                self.CreateCmpJobOKClose = function (event) {
                    document.querySelector('#createCmpJobDialog').close();
                    self.jobName('');
                    self.selectgrpName('');
                    
                };



                self.cancel = function () {
                    oj.Router.rootInstance.go('compare');

                }




                self.connected = function () { 
                    if (sessionStorage.getItem("userName")==null) {
                        oj.Router.rootInstance.go('signin');
                    }
                    else
                    {
                      app.onAppSuccess();
                    }
        
                };

                /**
                 * Optional ViewModel method invoked after the View is disconnected from the DOM.
                 */
                self.disconnected = function () {
                    // Implement if needed
                };

                /**
                 * Optional ViewModel method invoked after transition to the new View is complete.
                 * That includes any possible animation between the old and the new View.
                 */
                self.transitionCompleted = function () {
                    // Implement if needed
                };
            }

            /*
             * Returns an instance of the ViewModel providing one instance of the ViewModel. If needed,
             * return a constructor for the ViewModel so that the ViewModel is constructed
             * each time the view is displayed.
             */
            return  CompGrpViewModel;
        }
);
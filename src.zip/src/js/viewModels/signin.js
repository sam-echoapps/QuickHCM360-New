 'use strict';
 define(['ojs/ojcore', 'knockout', 'appController', 'appUtils',
         'ojs/ojknockout',
         'ojs/ojcheckboxset',
         'ojs/ojinputtext',
         'ojs/ojbutton',
         'ojs/ojvalidationgroup',
         'ojs/ojanimation','ojs/ojformlayout','ojs/ojdialog'], function(oj, ko, app, appUtils) {
   function signin() {
     var self = this;
 
     self.transitionCompleted = function() {
       appUtils.setFocusAfterModuleLoad('signInBtn');
       var animateOptions = { 'delay': 0, 'duration': '1s', 'timingFunction': 'ease-out' };
       oj.AnimationUtils['fadeIn'](document.getElementsByClassName('demo-signin-bg')[0], animateOptions);
     }
 
     self.groupValid = ko.observable();
     self.SignIn = ko.observable();
     self.LoginErr = ko.observableArray([]);
     self.OnePlaceuserName = ko.observable();
     self.OnePlacepassWord = ko.observable();

     self.signIn = function(data, event) {
            self.SignIn('');
            self.LoginErr([]);
            $.ajax({
                url: "http://192.168.0.11:8080/oneplogin",
                type: 'POST',
                data: JSON.stringify({
                    user: self.OnePlaceuserName(),
                    passwd : self.OnePlacepassWord()
                }),
                dataType: 'json',
                context: self,
                error: function (e) {
                    console.log(e);
                },
                success: function (data) {
                    if (data[1]== 'Y') {
                        self.SignIn('Y');
                        app.onLoginSuccess();
                        sessionStorage.setItem("userName", self.OnePlaceuserName());
                    }
                    else {
                        self.SignIn('N');
                        document.querySelector('#LoginErrDialog').open();
                        self.LoginErr(data[0]);
                     }
                     console.log(self);
                    return self;
                }

            })
     };
 
     self.LoginMsgOKClose = function () {
     document.querySelector('#LoginErrDialog').close();
     }

   }
   return signin;
 });
 
define(["knockout", "ojs/ojknockout","ojs/ojwaterfalllayout", "ojs/ojactioncard",'ojs/ojbutton',"ojs/ojswitch", 
            "ojs/ojlabelvalue", "ojs/ojlabel",'ojs/ojformlayout','ojs/ojdialog','ojs/ojprogress-bar'], 
function ( ko) {
    
    function  EnableMonitorViewModel () {
            var self = this;
            self.monVal = ko.observable();
            self.enableButtonValue = ko.observable();
            self.disableButtonValue = ko.observable();

        function getMonitorStatus() {
            self.monVal('');
            $.ajax({
                url: "http://192.168.0.11:8080/ggcheckmon",
                type: 'GET',
                dataType: 'json',
                context: self,
                error: function (e) {
                    console.log(e);
                },
                success: function (data) {
                    if (data[0]=='ENABLED') {
                    self.enableButtonValue(false);
                    self.disableButtonValue(true);
                    }
                    else {
                        self.enableButtonValue(true);
                        self.disableButtonValue(false);
                    }
                    self.monVal(data[0]);
                    console.log(self);
                    return self;
                }
            })
        }


        self.enableButtonHandler = function (data, event) {
            self.monVal('');
            $.ajax({
                url: "http://192.168.0.11:8080/ggmonitorall",
                type: 'POST',
                data: JSON.stringify({
                        monVal : 'ENABLED'
                }),
                dataType: 'json',
                contrep: self,
                error: function (e) {
                    console.log(e);
                },
                success: function (data) {
                    getMonitorStatus();
                    self.monVal(data[0]);
                    console.log(self);
                    return self;
                }
            })
        }

        self.disableButtonHandler = function (data, event) {
            self.monVal('');
            $.ajax({
                url: "http://192.168.0.11:8080/ggmonitorall",
                type: 'POST',
                data: JSON.stringify({
                        monVal : 'DISABLED'
                }),
                dataType: 'json',
                contrep: self,
                error: function (e) {
                    console.log(e);
                },
                success: function (data) {
                    getMonitorStatus();
                    self.monVal(data[0]);
                    console.log(self);
                    return self;
                }
            })
        }

        self.enableOKClose = function () {
            getMonitorStatus();
        }



                getMonitorStatus();
         

        }
        return EnableMonitorViewModel();
    });
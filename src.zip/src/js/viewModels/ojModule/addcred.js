define(['knockout', 'jquery','appController', 'ojs/ojarraydataprovider' ,'ojs/ojarraytreedataprovider','ojs/ojbutton', 'ojs/ojinputtext', 'ojs/ojselectcombobox' ,'ojs/ojdialog','ojs/ojformlayout','ojs/ojtreeview'],
        function (ko, $ ,app, ArrayDataProvider,ArrayTreeDataProvider ) {

            function addcredViewModel() {
                var self = this;
                self.addcred = ko.observable();



                self.username1 = ko.observableArray([]);
                self.aliasname1 = ko.observableArray([]);
                self.domname1=ko.observableArray([]);
                self.othdom = ko.observableArray([]);
                self.alias = ko.observable();
                self.user = ko.observable();
                self.valdom = ko.observable();
                self.uName = ko.observable();
                self.uPasswd = ko.observable();
                self.uRepPass = ko.observable();

                self.buttonValue = ko.observable('add');
                self.dombuttonValue = ko.observable('existDom');
                self.domName = ko.observable();
                self.aliasName = ko.observable();
                self.deluser = ko.observable('Oracle');
                
                self.credValues = ko.observableArray([
                    {id: 'add', label: 'add'},
                    {id: 'edit',    label: 'edit'},
                    {id: 'del',   label: 'del'}
                  ]);
              


                function getDomains() {
                    self.username1([]);
                    self.othdom([]);
                    self.aliasname1([]);
                    self.domname1([]);
                    self.selectedAliascategory('');
                    self.selectedUsercategory('');
                    self.aliasName('');
                    self.uRepPass()
                    self.uName('');
                    self.uPasswd('');
                    self.uRepPass('');
                    self.deluser('');
                    self.valdom('');

                    $.ajax({
                        url: "http://192.168.0.11:8080/ggcredstore",
                        type: 'GET',
                        dataType: 'json',
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                 
                          
                            for (var i = 0; i < data[1].length; i++) {
                                self.othdom.push({dom : data[1][i].value});
                                       }

                                       self.aliasname1(data[4]);


                                         for (var i = 0; i < data[2].length; i++) {
                                 self.domname1.push({label:data[2][i], value:data[2][i] }); 
                             }
    
                          for (var i = 0; i < data[0].length; i++) {
                                 self.username1.push({label:data[0][i].alias, value:data[0][i].alias,'children': [{label:data[0][i].uname,value:data[0][i].uname}] }); 
                             }
                                       
                                       
                                console.log(self)
                            
                           return self;
                        }
                    })
                }   

                self.clickAddCred = function (data, event) {
                  $.ajax({
                      url: "http://192.168.0.11:8080/ggaddcredstore",
                      type: 'GET',
                      dataType: 'json',

                      error: function (e) {
                          console.log(e);
                      },
                      success: function (data) {
                          self.addcred(data[0]);
                          document.querySelector('#credStoreDialog').open();
                          console.log(self)
                          return self;
                      }
                  })
              };
              
    self.credStoreOKClose = function (event) {
       document.querySelector('#credStoreDialog').close();
     };
      
      self.leafOnly = function (itemContext) {
        return itemContext.leaf;
      };
      
      self.succMsgDBLogin = ko.observable();
                self.selectedMenuItem = ko.observable('(None selected yet)');
                self.selectedMenuItem1 = ko.observable(1);
                self.currentKey = null;
                self.testMenu = ko.observable();
        
                self.menuBeforeOpen = function (event) {
                  var target = event.detail.originalEvent.target;
                  var treeView = document.getElementById('treeview');
                  var context = treeView.getContextByNode(target);
                  self.currentKey = context ? context.key: treeView.currentItem;
                  var context = treeView.getContextByNode(target);
                  var parentKey = context.parentKey;
                  self.selectedMenuItem1(parentKey);
                };
        
                self.menuAction = function (event,node,data){
                  self.data.fetchByKeys({ keys: new Set([self.currentKey]) }).then(function (e) {
                    if (e.results.get(self.currentKey)) {
                      self.selectedMenuItem(e.results.get(self.currentKey).data.value);
                      $.ajax({
                        url: "http://192.168.0.11:8080/testdblogin",
                        type: 'POST',
                      data: JSON.stringify({
                            domain : self.selectedMenuItem1(),
                            alias : self.selectedMenuItem()
                          }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                             document.querySelector('#testDBLoginDialog').open();
                             self.succMsgDBLogin(data[0]);
                             return self;
                        }
                    })
                    }
                  })
                };
                
                self.DBLoginOKClose = function (event) {
                  document.querySelector('#testDBLoginDialog').close();
                };

    self.selectedDomCategory = ko.observable('OracleGoldenGate');
    self.selectedAliascategory = ko.observable();
    self.selectedUsercategory= ko.observable();
    self.aliascategories = ko.observableArray([]);
    self.unamecategories = ko.observableArray([]);

    let getAliascategories = (category) => {
      let found = self.aliasname1().find(c => c.value === category);
      return found ? found.children : null;
    };
    let getUnamecategories = (category) => {
      let found = self.username1().find(c => c.value === category);
      return found ? found.children : null;
    };
    self.domSelectionChanged = (event) => {
      self.selectedAliascategory('');
      self.selectedUsercategory('');
      let children = getAliascategories(event.detail.value);
      self.aliascategories(children);
     };
                

   self.aliasSelectionChanged = (event) => {
      self.selectedUsercategory('');
      let children = getUnamecategories(event.detail.value);
      self.unamecategories(children);
    };
  

                
                self.data = new ArrayTreeDataProvider(self.aliasname1, { keyAttributes: 'value' });

                self.OthDomProvider = new ArrayDataProvider(self.othdom, {keyAttributes: 'value'});

                
                self.succMsgAddUser = ko.observable();

                    self.clickAddUsr = function (data, event) {
                    $.ajax({
                        url: "http://192.168.0.11:8080/ggaddusralias",
                        type: 'POST',
                      data: JSON.stringify({
                            domain: self.selectedDomCategory(),
                            alias: self.aliasName(),
                            user: self.uName(),
                            passwd: self.uPasswd()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                             document.querySelector('#addUserCredStoreDialog').open();
                             self.succMsgAddUser(data[0]);
                             getDomains();
                             return self;
                        }

                    })

                };
                
                      self.addUserOKClose = function (event) {
         document.querySelector('#addUserCredStoreDialog').close();
       };

                
                 self.succMsgedUsr = ko.observable();
                    self.clickEditUsr = function (data, event) {
                    $.ajax({
                        url: "http://192.168.0.11:8080/ggeditusralias",
                        type: 'POST',
                            data: JSON.stringify({
                            domain : self.selectedDomCategory(),
                            alias : self.selectedAliascategory(),
                            user: self.selectedUsercategory(),
                            passwd: self.uRepPass()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                             document.querySelector('#edUserCredStoreDialog').open();
                             self.succMsgedUsr(data[0]);
                             getDomains();
                             return self;
                        }

                    })

                };
                
                   self.edUserOKClose = function (event) {
         document.querySelector('#edUserCredStoreDialog').close();
       };


                self.succMsgDelUsr = ko.observable();
                
                    self.clickDelUsr = function (data, event) {
                    $.ajax({
                        url: "http://192.168.0.11:8080/ggdelusralias",
                        type: 'POST',
                      data: JSON.stringify({
                            domain : self.selectedDomCategory(),
                            alias : self.selectedAliascategory(),
                            user: self.selectedUsercategory()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                             document.querySelector('#delUserCredStoreDialog').open();
                             self.succMsgDelUsr(data[0]);
                             getDomains();
                             return self;
                        }

                    })

                };

      self.delUserOKClose = function (event) {
         document.querySelector('#delUserCredStoreDialog').close();
       };

       self.connected = function () { 
        if (sessionStorage.getItem("userName")==null) {
          oj.Router.rootInstance.go('signin');
      }
      else
      {
        app.onAppSuccess();
        getDomains();      
      }          
    };

    /**
     * Optional ViewModel method invoked after the View is disconnected from the DOM.
     */
    self.disconnected = function () {
        // Implement if needed

    };

    /**
     * Optional ViewModel method invoked after transition to the new View is complete.
     * That includes any possible animation between the old and the new View.
     */
    self.transitionCompleted = function () {
        // Implement if needed

    };
}

/*
 * Returns a constructor for the ViewModel so that the ViewModel is constructed
 * each time the view is displayed.  Return an instance of the ViewModel if
 * only one instance of the ViewModel is needed.
 */
            
            return  addcredViewModel;

        });
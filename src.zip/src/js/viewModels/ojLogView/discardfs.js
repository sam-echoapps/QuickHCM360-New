
define(['ojs/ojcore', 'knockout', 'jquery','appController', 'ojs/ojknockout-keyset','ojs/ojarraydataprovider', 'ojs/ojknockout', 'ojs/ojlistview', 'ojs/ojlistitemlayout', 'ojs/ojinputtext', 'ojs/ojlabel', 'ojs/ojformlayout','ojs/ojswitch'],
function (oj, ko, $, app, keySet , ArrayDataProvider) {

    function discardfsViewModel() {
        var self = this;
        self.dscFileList = ko.observableArray([]);

        function dscfile() {
            self.dscFileList([]);
            $.ajax({
                url: "http://192.168.0.11:8080/listdsc",
                type: 'GET',
                dataType: 'json',
                context: self,
                error: function (e) {
                    console.log(e);
                },
                success: function (data) {
                    for (var i = 0; i < data[0].length; i++) {
                        self.dscFileList.push({'dscfile': data[0][i]});
                    }
                    console.log(self);
                    return self;
                }
            })
        };

        self.dscfileDP = new ArrayDataProvider(self.dscFileList, {keyAttributes: 'dscfile'});

        self.selectedItems = new keySet.ObservableKeySet(); // observable bound to selection option to monitor current selections
        self.selectedSelectionRequired = ko.observable(true);
        self.firstSelectedItem = ko.observable();
        self.selectedDscFile = ko.observableArray([]);

        self.getDisplayValue = function (set) {
            var arr = [];
            set.values().forEach(function (key) {
                arr.push(key);
            });
            return JSON.stringify(arr);
        };




        self.dscFileContent = ko.observable();



        self.viewDsc = function (data, event) {
            self.dscFileContent('');
            $.ajax({
                url: "http://192.168.0.11:8080/viewdsc",
                type: 'POST',
                data: JSON.stringify({
                    dscFile: self.getDisplayValue(self.selectedItems())
                }),
                dataType: 'json',
                context: self,
                error: function (e) {
                    console.log(e);
                },
                success: function (data) {
                    self.dscFileContent(data[0]);
                    return self;
                }

            })
        }


        self.connected = function () { 
            if (sessionStorage.getItem("userName")==null) {
                oj.Router.rootInstance.go('signin');
            }
            else
            {
              app.onAppSuccess();
              self.dscFileList([]);
              dscfile();
            }
        };

        /**
         * Optional ViewModel method invoked after the View is disconnected from the DOM.
         */
        self.disconnected = function () {
            // Implement if needed

        };

        /**
         * Optional ViewModel method invoked after transition to the new View is complete.
         * That includes any possible animation between the old and the new View.
         */
        self.transitionCompleted = function () {
            // Implement if needed

        };
    }

    /*
     * Returns a constructor for the ViewModel so that the ViewModel is constructed
     * each time the view is displayed.  Return an instance of the ViewModel if
     * only one instance of the ViewModel is needed.
     */
    return  discardfsViewModel;
}
);

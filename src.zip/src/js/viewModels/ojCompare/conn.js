
define(['ojs/ojcore', 'knockout', 'jquery','appController' ,'ojs/ojknockout', 'ojs/ojtrain', 'ojs/ojradioset', 'ojs/ojbutton', 'ojs/ojlabelvalue', 'ojs/ojdatetimepicker', 'ojs/ojlabel', 'ojs/ojformlayout', 'ojs/ojinputtext', 'ojs/ojselectsingle', 'ojs/ojinputnumber', 'ojs/ojvalidationgroup', 'ojs/ojselectcombobox', 'ojs/ojdialog'],
        function (oj, ko, $, app) {

            function ConnViewModel() {
                var self = this;
                        this._HELP_SOURCE = 'http://www.oracle.com';
        this._HELP_DEF = 'hostname.domainname:dbport/dbservice';

                this.isRequired = ko.observable(true);
                this.checkboxValues = ko.observableArray(['required', 'helpSource', 'helpDef']);

                this.isRequired = ko.computed(function () {
                    return this.checkboxValues.indexOf('required') !== -1;
                }.bind(this));
                this.helpDef = ko.computed(function () {
                    return (this.checkboxValues.indexOf('helpDef') !== -1) ? this._HELP_DEF : null;
                }.bind(this));
                this.helpSource = ko.computed(function () {
                    return (this.checkboxValues.indexOf('helpSource') !== -1) ? this._HELP_SOURCE : null;
                }.bind(this));

                this.isFormReadonly = ko.observable(false);

                self.CreateConnMsg = ko.observable();
                self.connName = ko.observable();
                self.uName = ko.observable();
                self.uPasswd = ko.observable();
                self.connString = ko.observable();

                self.createConn = function (data, event) {
                    $.ajax({
                        url: "http://192.168.0.11:8080/createconn",
                        type: 'POST',
                        data: JSON.stringify({
                            connName: self.connName(),
                            uName: self.uName(),
                            uPasswd: self.uPasswd(),
                            connString:self.connString()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#CreateConnDialog').open();
                            self.CreateConnMsg(data[0]);
                            return self;
                        }
                    })
                }

                self.CreateConnOKClose = function (event) {
                    document.querySelector('#CreateConnDialog').close();
                            self.connName('');
                            self.uName('');
                            self.uPasswd('');
                            self.connString('');
                };



                self.connNameList = ko.observableArray([]);

                function connlist() {
                    self.connNameList([]); 
                    $.ajax({
                        url: "http://192.168.0.11:8080/supplog",
                        type: 'GET',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            
                            for (var i = 0; i < data[2].length; i++) {

                                self.connNameList.push({label: data[2][i].CONNNAME, value:data[2][i].CONNNAME});
                            }

                            console.log(self);
                            return self;
                        }

                    })

                }
                
                connlist();
            
                self.connlistDP = new oj.ArrayDataProvider(self.connNameList, {keyAttributes: 'connName'});
               
                self.CreateGrpMsg = ko.observable();
                self.srcconnName = ko.observable();
                self.tgtconnName = ko.observable();
                self.grpName = ko.observable();
               
                self.createGrp = function (data, event) {
                    $.ajax({
                        url: "http://192.168.0.11:8080/creategrp",
                        type: 'POST',
                        data: JSON.stringify({
                            grpName : self.grpName(),
                            srcConnName: self.srcconnName(),
                            tgtConnName: self.tgtconnName()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#CreateGrpDialog').open();
                            self.CreateGrpMsg(data[0]);
                            return self;
                        }
                    })
                }
               
                self.CreateGrpOKClose = function (event) {
                    document.querySelector('#CreateGrpDialog').close();
                            self.grpName('');
                            self.srcconnName('');
                            self.tgtconnName('');
                };

                self.connected = function () { 
                    if (sessionStorage.getItem("userName")==null) {
                        oj.Router.rootInstance.go('signin');
                    }
                    else
                    {
                      app.onAppSuccess();
                    }
        
                };

                /**
                 * Optional ViewModel method invoked after the View is disconnected from the DOM.
                 */
                self.disconnected = function () {
                    // Implement if needed
                };

                /**
                 * Optional ViewModel method invoked after transition to the new View is complete.
                 * That includes any possible animation between the old and the new View.
                 */
                self.transitionCompleted = function () {
                    // Implement if needed
                };
            }

            /*
             * Returns an instance of the ViewModel providing one instance of the ViewModel. If needed,
             * return a constructor for the ViewModel so that the ViewModel is constructed
             * each time the view is displayed.
             */
            return  ConnViewModel;
        }
);
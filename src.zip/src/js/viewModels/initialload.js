define(['knockout', 'jquery','appController',  'ojs/ojasyncvalidator-regexp', 'ojs/ojconverterutils-i18n', 'ojs/ojconverter-datetime', 'ojs/ojconverter-number',"ojs/ojpagingdataproviderview",'ojs/ojarraydataprovider',"ojs/ojlistdataproviderview","ojs/ojkeyset", 'ojs/ojknockout', 'ojs/ojtrain', 'ojs/ojradioset', 'ojs/ojbutton', 'ojs/ojlabelvalue', 'ojs/ojdatetimepicker', 'ojs/ojlabel', 'ojs/ojformlayout', 'ojs/ojinputtext', 'ojs/ojselectsingle', 'ojs/ojinputnumber', 'ojs/ojvalidationgroup', 'ojs/ojselectcombobox', 'ojs/ojdialog', 'ojs/ojswitch','ojs/ojcheckboxset','ojs/ojprogress-bar','ojs/ojtable','ojs/ojhighlighttext',"ojs/ojpagingcontrol"],
        function (ko, $,app,AsyncRegExpValidator, ConverterUtilsI18n, DateTimeConverter, NumberConverter, PagingDataProviderView,ArrayDataProvider,ListDataProviderView,ojkeyset_1) {

            class InitialLoadViewModel {
 
                constructor(args) {
                var self = this;

                self.optParam = ko.observableArray([',']);
                self.startExtChk = ko.observable(true);

                self.currentTrailType = ko.observable('exttrail');
                self.currentPDB = ko.observable();


                self.paramValue = ko.observable("text area value");
                self.currentPassThru = ko.observable('passthru');
                self.rmtHostName = ko.observable();
                self.rmtMgrPort = ko.observable();
                self.ButtonVal = ko.observable();

                self.isDDLChecked = ko.observable();

                self.isGetTruncChecked = ko.observable();
                self.isEncrytChecked = ko.observable();
                self.isNoUseSnapChecked = ko.observable();
                self.isExcludeTagChecked = ko.observable();
                self.isGetUpdBefChecked = ko.observable();
                self.Threads = ko.observable(1);
                this.selectionInfo = ko.observable("");
                self.schemaList = ko.observableArray([]);

                
                self.LMDict = ko.observableArray([]);
                self.CaptureList = ko.observableArray([]);
                self.CaptureName = ko.observable(' ');
                self.CDBCheck =  ko.observable();
                self.PDBList  = ko.observableArray([]);
                self.PDBName = ko.observableArray([]);

                self.queryDBLMDict =    function(event,data) {
                    self.CDBCheck('');
                    self.PDBList([]);
                    self.PDBName([]);
                    self.CDBCheck('');
                    self.LMDict([]);
                    self.CaptureList([]);
                    $.ajax({
                        url: "http://ANEESHTV84.HOPTO.ORG:8080/lmdictdet",
                        type: 'POST',
                        dataType: 'json',
                        data: JSON.stringify({
                            dbname : self.selectedAliascategory()
                        }),
                       context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            self.CDBCheck(data[0]);
                            for (var i = 0; i < data[1].length; i++) {   
                                    self.PDBList.push({ 'label' : data[1][i].NAME , 'value' : data[1][i].NAME });
                            }
                            for (var i = 0; i < data[2].length; i++) {           
                                self.CaptureList.push({'label' : data[2][i].CLIENT_NAME, 'value' : data[2][i].CLIENT_NAME});
                            }
                            for (var i = 0; i < data[3].length; i++) {           
                                self.LMDict.push(data[3][i]);
                            }
                            return self;
                        }
                    })
                }
                
                self.DBLMDictDP = new ArrayDataProvider(self.LMDict, {keyAttributes: 'FIRST_CHANGE',textFilterAttributes: ['FIRST_CHANGE', 'FIRST_TIME']});
                self.CaptureListDP = new ArrayDataProvider(self.CaptureList, {keyAttributes: 'value'});
                self.PDBListDP = new ArrayDataProvider(self.PDBList, {keyAttributes: 'value'});

                self.ExtPrmList = ko.observableArray([]);
                self.ExtTrailName = ko.observable();
                self.queryExtPrm =    function(event,data) {
                    self.ExtPrmList([]);
                    self.ExtTrailName('');
                    $.ajax({
                        url: "http://ANEESHTV84.HOPTO.ORG:8080/gggetextprm",
                        type: 'POST',
                        dataType: 'json',
                        data: JSON.stringify({
                            currentextname : self.CurrentExtName()
                        }),
                       context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                                    self.ExtPrmList(data[0]);
                                    self.ExtTrailName(data[1]);
                          return self;
                        }
                    })
                }




                self.lmDictSCN = ko.observable(' ');


                self.getItemText = function (itemContext) {
                    return itemContext.data.FIRST_CHANGE;
                  };

               self.tableColumns = [
                    {"headerText": "SCN", "field": "FIRST_CHANGE","template": "cellTemplate"},
                    {"headerText": "Time", "field": "FIRST_TIME","template": "cellTemplate"}
                  ];
              
                  self.regVal = ko.observable('now');
                  self.regOptions = [
                    { id: 'now', value: 'now', label: 'Now' },
                    { id: 'existscn', value: 'existscn', label: 'Existing Dictionary' }
                  ];

                  self.lmShareOpt = ko.observableArray([
                    {label: 'AUTOMATIC', value: 'AUTOMATIC'},
                    {label: 'NONE', value: 'NONE'},
                    {label: 'EXTRACT', value: 'EXTRACT'}
                ]);
                self.lmShareOptDP = new ArrayDataProvider(self.lmShareOpt, {keyAttributes: 'value'});     

                self.currentShareOpt = ko.observable('NONE');


                self.PDBName = ko.observableArray([]);


                
                self.CurrentExtName = ko.observable();
                self.ExtList = ko.observableArray([]);

                function getExtTrails() {
                    self.CurrentExtName('');
                    self.ExtList([]);
                    $.ajax({
                        url: "http://ANEESHTV84.HOPTO.ORG:8080/gggetexttrail",
                        type: 'GET',
                        dataType: 'json',
                       context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            for (var i = 0; i < data[0].length; i++) {           
                                self.ExtList.push({'label' : data[0][i].label, 'value' : data[0][i].label});
                            }
                            return self;
                        }
                    })
                }

                self.ExtListDP = new ArrayDataProvider(self.ExtList, {keyAttributes: 'value'});

self.currentParamList = ko.computed(function() {
    if(self.optParam()) {
       return self.optParam().toString().replace(/[,]/g,"\n");
    }
    else
    {
        return '';
        
    }
    });


    self.ExtPrmList1 = ko.computed(function() {
        if(self.ExtPrmList()) {
           return self.ExtPrmList().join('');
        }
        else
        {
            return '';
            
        }
        });


                self.currentExtType = ko.observable('SOURCEISTABLE');
                     
                     
                self.extType = ko.observableArray([
                    {label: 'Initial Load Extract', value: 'SOURCEISTABLE'},
                    {label: 'Initial Load Replicat', value: 'ILR'}
                ]);



                self.CEOPT = ko.observable('LR');
                self.regExtChk = ko.observable(true);

                self.extractDP = new ArrayDataProvider(self.extType, {keyAttributes: 'value'});
       
                self.isFormReadonly = ko.observable(false);

                
                self.selectedStepValue = ko.observable('stp1');
                self.selectedStepLabel = ko.observable('DataSource');
                self.selectedStepFormLabel = ko.observable('DataSource');

                self.stepArray =
                        ko.observableArray([
                            {label: 'DataSource', id: 'stp1'},
                            {label: 'Extract Options', id: 'stp2'},
                            {label: 'Parameter File', id: 'stp3'}
                        ]);

                self.ExtName = ko.observable();
                self.ExtDesc = ko.observable();

                self.categorySelectionChanged = (event) => {
                    self.selectedSubcategory('');
                    let sub = getSubcategories(event.detail.value);
                    self.subcategories(sub);
                };

                self.ctvalue = ko.observable(ConverterUtilsI18n.IntlConverterUtils.dateToLocalIso(new Date()));

                self.secondConverter = new DateTimeConverter.IntlDateTimeConverter(
                        {
                            pattern: "yyyy-MM-dd HH:mm:ss"
                        });
                self.csnvalue = ko.observable();

                self.decimalHalfDownConverter =
                        new NumberConverter.IntlNumberConverter({
                            style: 'decimal',
                            roundingMode: 'HALF_DOWN',
                            maximumFractionDigits: 0,
                            useGrouping: false
                        });


                self.ExtTrail = ko.observable();
                self.ExtTrailSize = ko.observable('500');

                self.modeVal = ko.observable("Integrated Tranlog");

                self.currentbeginmode = ko.observable('Begin Now');

                self.TrailName = ko.observable();
                self.trailSubDir = ko.observable();
                self.trailSubDirSlash = ko.observable('/');
                self.trailSize = ko.observable(500);

                self.beginmode = ko.observableArray([
                    {value: 'Begin Now', label: 'Now'},
                    {value: 'Begin ', label: 'Custom Time'},
                    {value: 'CSN', label: 'CSN'}
                ]);

                self.startOptionDP = new ArrayDataProvider(self.beginmode, {keyAttributes: 'value'});

                self.username1 = ko.observableArray([]);
                self.aliasname1 = ko.observableArray([]);
                self.domname1 = ko.observableArray([]);
                self.othdom = ko.observableArray([]);
                self.alias = ko.observable();
                self.user = ko.observable();
                self.valdom = ko.observable();
                self.uName = ko.observable();
                self.uPasswd = ko.observable();
                self.uRepPass = ko.observable();

                self.selectedDomCategory = ko.observable();
                self.selectedAliascategory = ko.observable();
                self.selectedUsercategory = ko.observable();
                self.aliascategories = ko.observableArray([]);
                self.unamecategories = ko.observable();

                function getDomains() {
                    self.username1([]);
                    self.othdom([]);
                    self.aliasname1([]);
                    self.domname1([]);
                    self.selectedAliascategory('');
                    self.selectedUsercategory('');
                    self.uRepPass()
                    self.uName('');
                    self.uPasswd('');
                    self.uRepPass('');
                    self.valdom('')
                    $.ajax({
                        url: "http://ANEESHTV84.HOPTO.ORG:8080/ggcredstore",
                        type: 'GET',
                        dataType: 'json',
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {

                            for (var i = 0; i < data[1].length; i++) {
                                self.othdom.push({dom : data[1][i].value});
                                       }

                                       self.aliasname1(data[4]);


                                         for (var i = 0; i < data[2].length; i++) {
                                 self.domname1.push({label:data[2][i], value:data[2][i] }); 
                             }
    
                          for (var i = 0; i < data[0].length; i++) {
                                 self.username1.push({label:data[0][i].alias, value:data[0][i].alias,'children': [{label:data[0][i].uname,value:data[0][i].uname}] }); 
                             }

                            return self;
                        }
                    })
                }




                let getAliascategories = (category) => {
                    let found = self.aliasname1().find(c => c.value === category);
                    return found ? found.children : null;
                };
                let getUnamecategories = (category) => {
                    let found = self.username1().find(c => c.value === category);
                    return found ? found.children : null;
                };
                self.domSelectionChanged = (event) => {
                    self.selectedAliascategory('');
                    let children = getAliascategories(event.detail.value);
                    self.aliascategories(children);
                };


                self.aliasSelectionChanged = (event) => {
                    self.selectedUsercategory('');
                    let children = getUnamecategories(event.detail.value);
                    self.unamecategories(children);
                };

                self.value = ko.observable();

                self.groupValid = ko.observable();
                
                self.tmpPrm = ko.observable();

               


                self.isRequired = ko.observable(true);
                self.checkboxValues = ko.observableArray(['required', 'helpSource', 'helpDef']);

                self.isRequired = ko.computed(function () {
                    return self.checkboxValues.indexOf('required') !== -1;
                });
                self.helpDef = ko.computed(function () {
                    return (self.checkboxValues.indexOf('helpDef') !== -1) ? self._HELP_DEF : null;
                });
                self.helpSource = ko.computed(function () {
                    return (self.checkboxValues.indexOf('helpSource') !== -1) ? self._HELP_SOURCE : null;
                });

                self.regExpValidator =
                        new AsyncRegExpValidator({
                            pattern: "[a-zA-Z0-9,.'-]{1,}",
                            hint: "1 or more letters",
                            messageDetail: "You must enter at least 1 letter"
                        });

                        self.emailRegExpValidator =
                        new AsyncRegExpValidator({
                            pattern: ".+\@.+\..+",
                            hint: "email format",
                            messageDetail: "Invalid email format"
                        });

                self.previousStep = function () {
                    var train = document.getElementById('train');
                    var prev = train.getPreviousSelectableStep();
                    if (prev != null) {
                        self.selectedStepValue(prev);
                        self.selectedStepLabel(train.getStep(prev).label);
                        self.selectedStepFormLabel(train.getStep(prev).label);
                    }
                };

                self.nextStep = function (event) {
                    var train = document.getElementById('train');
                    var next = train.getNextSelectableStep();
                    var tracker = document.getElementById("tracker");
                    
                  
                    
                    if (tracker == null) {
                        return;
                    }
                    if (tracker.valid === "valid") {
                        //The previous step will have a confirmation message type icon
                        self.selectedStepLabel.messageType = 'confirmation';
                        document.getElementById("train").updateStep(self.selectedStepValue, self.selectedStepValue);
                        //Now the clicked step could be selected
                        self.selectedStepValue(next);
                        self.selectedStepLabel(train.getStep(next).label);
                        self.selectedStepFormLabel(train.getStep(next).label);
                        return;
                    } else {
                        //The ojBeforeSelect can be cancelled by calling event.preventDefault().
                        event.preventDefault();
                        //The previous step will have an error message type icon
                        self.selectedStepLabel.messageType = 'error';
                        document.getElementById("train").updateStep(self.selectedStepLabel.id, self.selectedStepLabel);
                        // show messages on all the components
                        // that have messages hidden.
                        tracker.showMessages();
                        tracker.focusOn("@firstInvalidShown");
                        return;
                    }

                }.bind(this);
                //It is being called by the train to make sure the form is valid before moving on to the next step.



                    
                    
self.currentExtParamList = ko.observable();
self.currentPmpParamList = ko.observable();

self.newparamList =  ko.observable('');

//start

//console.log(selectedData[1]);

self.currenSchemaParam = ko.computed( { 
    read:function() {
        var currenSchemaParam ='';
        if (self.selectionInfo().length > 0){
        let selectedData = self.selectionInfo().split(",");
        for(var i =0 ; i< selectedData.length; i++){
            currenSchemaParam = currenSchemaParam +'TABLEEXCLUDE ' +  selectedData[i] + '\n';
        }
    }
      return currenSchemaParam;
        
  },
  write: function(newVal) {
      var currenSchemaParam = newVal;
      return newVal;
  }
  });

  self.SchemaParam = ko.computed( { 
    read:function() {
        var SchemaParam ='';
        for(var i =0 ; i< self.schemaList().length; i++){
            SchemaParam = SchemaParam +'TABLE ' +  self.schemaList()[i] + ".* , SQLPREDICATE 'AS OF SCN " + self.dbDetList()[0].current_scn + "';" + '\n';
        }
      return SchemaParam;
        
  },
  write: function(newVal) {
      var SchemaParam = newVal;
      return newVal;
  }
  });

  self.rmthostParam = ko.computed( { 
    read:function() {
        var rmthostParam ='';
        if (self.currentTrailType() == 'rmttrail')
        {
        var rmthostParam = 'RMTHOST ' + self.rmtHostName() + ',MGRPORT '  + self.rmtMgrPort() ;
        }
      return rmthostParam;
        
  },
  write: function(newVal) {
      var rmthostParam = newVal;
      return newVal;
  }
  });

//end

self.currentExtParam = ko.computed( { 
    read:function() {
      var currentExtParam = 'EXTRACT ' + self.ExtName() + '\n' + 'useridalias '+ self.currentPDB() + ' domain ' + self.selectedDomCategory() + '\n' + self.rmthostParam()  + '\n' + self.currentTrailType() +  '  ' + self.trailSubDir() + self.trailSubDirSlash() + self.TrailName() + '\n' + 'REPORTCOUNT EVERY 5 MINUTES, RATE' + '\n'  + self.currentParamList()  + '\n' + self.currenSchemaParam() + self.SchemaParam() ;
      return currentExtParam;
  },
  write: function(newVal) {
      var currentExtParam = newVal;
      return newVal;
  }
  });



    self.currentExtParamList = self.currentExtParam;




                
                //The method updates the label text to show what step the user is on
                self.updateLabelText = function (event) {
                    if (self.selectedStepValue == 'stp2') {
                        self.selectedStepFormLabel('Extract Options');
                        self.isFormReadonly(false);
                    } else if (self.selectedStepValue == "stp1") {
                        self.selectedStepFormLabel('Extract Type');
                        self.isFormReadonly(false);
                    } else if (self.selectedStepValue == "stp3") {
                        self.selectedStepFormLabel('Parameter File');
                        self.isFormReadonly(true);
                    }
                }.bind(this);

                self.AddExtractMsg = ko.observableArray([]);

                self.cancel = function () {
                    self.router.go({path : 'manage'});
                }

                self.addIE = function (data, event) {
                    self.currentExtParamList('');
                    self.AddExtractMsg([]);
                    document.querySelector('#CreateExtractDialog').open();
                    $.ajax({
                        url: "http://ANEESHTV84.HOPTO.ORG:8080/ggaddie",
                        type: 'POST',
                        data: JSON.stringify({
                            regExtChk : self.regExtChk(),
                            regVal : self.regVal(), 
                            lmDictSCN : self.lmDictSCN(),
                            currentShareOpt : self.currentShareOpt(),
                            CaptureName : self.CaptureName(),
                            extname: self.ExtName(),
                            extdesc: self.ExtDesc(),
                            domain: self.selectedDomCategory(),
                            alias: self.currentPDB(),
                            mode: self.currentExtType(),
                            beginmode: self.currentbeginmode(),
                            trailtype: self.currentTrailType(),
                            trailsubdir: self.trailSubDir(),
                            trailsubdirslash : self.trailSubDirSlash(),
                            trail: self.TrailName(),
                            trailsize: self.trailSize(),
                            currentExtParamList : self.newparamList(),
                            startExtChk : self.startExtChk(),
                            CDBCheck : self.CDBCheck(),
                            PDBName : self.PDBName()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#CreateExtractDialog').close();
                            document.querySelector('#AddExtractDialog').open();
                            self.AddExtractMsg(data[0]);
                            return self;
                        }

                    })
                }


                self.addCE = function (data, event) {
                    self.currentExtParamList('');
                    self.AddExtractMsg([]);
                    document.querySelector('#CreateExtractDialog').open();
                    $.ajax({
                        url: "http://ANEESHTV84.HOPTO.ORG:8080/ggaddce",
                        type: 'POST',
                        data: JSON.stringify({
                            extname: self.ExtName(),
                            extdesc: self.ExtDesc(),
                            domain: self.selectedDomCategory(),
                            alias: self.selectedAliascategory(),
                            mode: self.currentExtType(),
                            threads: self.Threads(),
                            beginmode: self.currentbeginmode(),
                            trailtype: self.currentTrailType(),
                            trailsubdir: self.trailSubDir(),
                            trailsubdirslash : self.trailSubDirSlash(),
                            trail: self.TrailName(),
                            trailsize: self.trailSize(),
                            currentExtParamList : self.newparamList(),
                            startExtChk : self.startExtChk()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#CreateExtractDialog').close();
                            self.AddExtractMsg(data[0]);
                            document.querySelector('#AddExtractDialog').open();
                            return self;
                        }

                    })
                }


                self.addPumpPT = function (data, event) {
                    self.AddExtractMsg([]);
                    document.querySelector('#CreateExtractDialog').open();
                    $.ajax({
                        url: "http://ANEESHTV84.HOPTO.ORG:8080/ggaddpumppt",
                        type: 'POST',
                        data: JSON.stringify({
                            extname: self.ExtName(),
                            extdesc: self.ExtDesc(),
                            mode: self.currentExtType(),
                            srcTrail: self.ExtTrailName(),
                            beginmode: self.currentbeginmode(),
                            trailsubdir: self.trailSubDir(),
                            trailsubdirslash : self.trailSubDirSlash(),
                            trail: self.TrailName(),
                            trailsize: self.trailSize(),
                            currentPmpParamList : self.newparamList(),
                            startPmpChk : self.startExtChk()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#CreateExtractDialog').close();
                            self.AddExtractMsg(data[0]);
                            document.querySelector('#AddExtractDialog').open();
                            return self;
                        }

                    })
                }
                self.args = args;
                // Create a child router with one default path
                self.router = self.args.parentRouter;


                self.AddExtractOKClose = function () {
                    document.querySelector('#AddExtractDialog').close();
                    if (self.AddExtractMsg().toString().includes('ERROR'))
                    {
                        self.router.go({path : 'addextract'});
                    }
                    else 
                    {
                        self.router.go({path :'manage'});
                    }
                };


                self.schemaNameList = ko.observableArray([]);
                
                self.dbDetList = ko.observableArray([]);

                self.DBSchema = function (data, event) {
                    document.querySelector('#SelectSchemaDialog').open();
                    self.schemaNameList([]);
                    self.dbDetList([]);
                    $.ajax({
                        url: "http://ANEESHTV84.HOPTO.ORG:8080/supplogschema",
                        type: 'POST',
                        data: JSON.stringify({
                            dbname : self.currentPDB()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            for (var i = 0; i < data[0].length; i++) {
                                self.schemaNameList.push({ 'label': data[0][i].USERNAME, 'value': data[0][i].USERNAME });
                            }
                            self.schemaNameList.valueHasMutated();
                            for (var i = 0; i < data[1].length; i++) {
                                self.dbDetList.push({ 'dbid': data[1][i].DBID,'dbname' : data[1][i].DBNAME,'pdbname' : data[1][i].PDBNAME,'platform' : data[1][i].PLATFORM_NAME  ,'host' : data[1][i].HOST,'version' : data[1][i].VERSION,'dbedition' : data[1][i].DB_EDITION , 'db_role' : data[1][i].DATABASE_ROLE , 'current_scn' : data[1][i].CURRENT_SCN , 'cdb' : data[1][i].CDB});
                            }
                            self.dbDetList.valueHasMutated();
                            document.querySelector('#SelectSchemaDialog').close();
                            return self;
                            
                        }
    
                    })
                }

                self.schemaNameListDP = new ArrayDataProvider(self.schemaNameList, {keyAttributes: 'value'});           
                self.dbDetListDP = new ArrayDataProvider(self.dbDetList, {keyAttributes: 'dbid'});    

                self.tableNameList = ko.observableArray([]);

                self.SchemaFetch = function (data, event) {
                    document.querySelector('#SelectSchemaDialog').open();
                    self.tableNameList([]);
                    $.ajax({
                        url: "http://ANEESHTV84.HOPTO.ORG:8080/tablelist",
                        type: 'POST',
                        data: JSON.stringify({
                            dbname : self.currentPDB(),
                            schemaList : self.schemaList()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            for (var i = 0; i < data[0].length; i++) {
                                self.tableNameList.push({'TABLE_NAME': data[0][i].OWNER + '.' + data[0][i].TABLE_NAME , 'ROWCNT' : data[0][i].NUM_ROWS ,'AVGSPC': data[0][i].AVG_SPACE,'ANALYZETIME' : data[0][i].LAST_ANALYZED});
                            }
                            console.log(self);
                            document.querySelector('#SelectSchemaDialog').close();
                            return self;
                        }
    
                    })
                }
                
                self.tableNameListDP = new PagingDataProviderView(new ArrayDataProvider(self.tableNameList, {idAttribute: 'TABLE_NAME'}));      

                self.tableListcolumnArray = [
                {headerText: 'Schema.Table Name',
                field: 'TABLE_NAME'},
                {headerText: 'Row Count',
                field: 'ROWCNT'},
                {headerText: 'Average Size(MB)',
                field: 'AVGSPC'},
                {headerText: 'Analyze Time',
                field: 'ANALYZETIME'} ]

          self.dbDetcolumnArray = [{headerText: 'DB Name',
                field: 'dbname'},
                {headerText: 'PDB Name',
                field: 'pdbname'},
                {headerText: 'Platform',
                field: 'platform'},
                {headerText: 'Host',
                field: 'host'},
                {headerText: 'Version',
                field: 'version'} ,
                {headerText: 'DB Edition',
                field: 'dbedition'} ,
                {headerText: 'DB Role',
                field: 'db_role'} ,
                {headerText: 'Current SCN',
                field: 'current_scn'} ,
                {headerText: 'CDB',
                field: 'cdb'} ,
             ]

             self.valueChangedHandler = (event) => {
                self.ButtonVal(false);
            };

            this.selectedItems = ko.observable({
                row: new ojkeyset_1.KeySetImpl(),
                column: new ojkeyset_1.KeySetImpl(),
            });
            
            this.selectedSelectionMode = ko.observable({
                row: "multiple",
                column: "none",
            });
            this.selectionModes = [
                { value: { row: "none", column: "single" }, label: "Single Column" },
                { value: { row: "none", column: "multiple" }, label: "Multiple Column" },
                { value: { row: "single", column: "none" }, label: "Single Row" },
                { value: { row: "multiple", column: "none" }, label: "Multiple Row" },
            ];
            this.selectionModeDP = new ArrayDataProvider(this.selectionModes, {
                keyAttributes: "value",
            });

            this.selectedChangedListener = (event) => {
                let selectionText = "";
                if (event.detail.value.row.isAddAll()) {
                    const iterator = event.detail.value.row.deletedValues();
                    iterator.forEach(function (key) {
                        selectionText =
                            selectionText.length === 0 ? `${key}`  : `${selectionText}, ${key}`;
                    });
                    if (iterator.size > 0) {
                        selectionText = " except " + selectionText;
                    }
                    selectionText = '' + selectionText;
                }
                else {
                    const row = event.detail.value.row;
                    const column = event.detail.value.column;
                    if (row.values().size > 0) {
                        row.values().forEach(function (key) {
                            selectionText += selectionText.length === 0 ? key : ", " + key;
                        });
                        selectionText = '' + selectionText;
                    }
                    if (column.values().size > 0) {
                        column.values().forEach(function (key) {
                            selectionText += selectionText.length === 0 ? key : ", " + key;
                        });
                        selectionText = "Column Selection:\nColumn Keys: " + selectionText;
                    }
                }
                this.selectionInfo(selectionText);
            };
            this.selectedSelectionMode.subscribe((newValue) => {
                // Reset selected Items on selection mode change.
                this.selectedItems({ row: new ojkeyset_1.KeySetImpl(), column: new ojkeyset_1.KeySetImpl() });
            });

           console.log(self.dbDetList.current_scn)


                self.connected = function () { 
                    if (sessionStorage.getItem("userName")==null) {
                        self.router.go({path : 'signin'});
                    }
                    else
                    {
                    getDomains();
                    getExtTrails();
                    app.onAppSuccess();
                    self.optParam([]);
                    self.selectedStepValue('stp1');
                    self.selectedStepLabel('DataSource');
                    self.selectedStepFormLabel('DataSource');
                    self.currentExtType('SOURCEISTABLE');
                    self.ExtName('');
                    self.ExtDesc('');
                    self.currentbeginmode('Begin Now');
                    self.trailSubDir('');
                    self.TrailName('');
                    self.regVal('now');
                    self.regExtChk(true);
                    self.LMDict([]);
                    self.CaptureList([]);
                    self.CaptureName('');
                    self.CDBCheck('');
                    self.PDBList([]);
                    self.PDBName('');
                    self.ButtonVal(true);
                    }
                }

                /**
                 * Optional ViewModel method invoked after the View is disconnected from the DOM.
                 */
                self.disconnected = function () {

                    // Implement if needed
                };

                /**
                 * Optional ViewModel method invoked after transition to the new View is complete.
                 * That includes any possible animation between the old and the new View.
                 */
                self.transitionCompleted = function () {

                };
            }
        }
            return  InitialLoadViewModel;
        }
);


define(['knockout','ojs/ojmodule-element-utils', 'ojs/ojmodule-element', 'ojs/ojbutton', 'ojs/ojmoduleanimations','ojs/ojinputtext'],
        function ( ko,moduleUtils) {

            function AdminViewModel() {

 function resolveVVM(name, moduleConfig) {
        var viewPath = name !== 'oj:blank' ? 'views/ojModule/' + name + '.html' : null;
        var modelPath = name !== 'oj:blank' ? 'viewModels/ojModule/' + name : null;
        var masterPromise = Promise.all([
          moduleUtils.createView({'viewPath':viewPath}),
          moduleUtils.createViewModel({'viewModelPath':modelPath})
        ]);
        masterPromise.then(
          function(values){
            moduleConfig({'view':values[0],'viewModel':values[1]});
          },
          function(reason){}
        );
      };
      
      var self = this;
      self.currentModule = ko.observable("addcred");
      self.moduleConfig = ko.observable({'view':[],'viewModel':null});
      
      resolveVVM(self.currentModule(), self.moduleConfig);
      self.currentModule.subscribe(function(name) {
        resolveVVM(name, self.moduleConfig);
      });
    
                self.disconnected = function () {
                    // Implement if needed
                };

                self.transitionCompleted = function () {
                    // Implement if needed
                };

            }
            return  AdminViewModel;

        });

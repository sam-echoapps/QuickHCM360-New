define(['ojs/ojcore', 'knockout', 'jquery','appController' , 'ojs/ojkeyset','ojs/ojknockout',  'ojs/ojbutton', 'ojs/ojlabelvalue', 'ojs/ojlabel', 'ojs/ojformlayout', 'ojs/ojinputtext', 'ojs/ojselectsingle', 'ojs/ojselectcombobox', 'ojs/ojdialog','ojs/ojtable', 'ojs/ojpagingcontrol'],
        function (oj, ko, $, app , keySet) {
            
    function CompJobViewModel() {
                var self = this;
                        this._HELP_SOURCE = 'http://www.oracle.com';
                        this._HELP_DEF = 'hostname.domainname:dbport/dbservice';

                this.isRequired = ko.observable(true);
                this.checkboxValues = ko.observableArray(['required', 'helpSource', 'helpDef']);

                this.isRequired = ko.computed(function () {
                    return this.checkboxValues.indexOf('required') !== -1;
                }.bind(this));
                this.helpDef = ko.computed(function () {
                    return (this.checkboxValues.indexOf('helpDef') !== -1) ? this._HELP_DEF : null;
                }.bind(this));
                this.helpSource = ko.computed(function () {
                    return (this.checkboxValues.indexOf('helpSource') !== -1) ? this._HELP_SOURCE : null;
                }.bind(this));

                this.isFormReadonly = ko.observable(false);
                self.jobName = ko.observable();

    self.jobNameList = ko.observableArray([]);

                function jobList() {
                    self.jobNameList([]);
                    $.ajax({
                        url: "htt://10.65.4.155:8080/joblist",
                        type: 'GET',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {

                            for (var i = 0; i < data[0].length; i++) {

                                self.jobNameList.push({label: data[0][i].JOBNAME, value: data[0][i].JOBNAME});
                            }

                            console.log(self);
                            return self;
                        }

                    })

                }

                jobList();
                
                self.selectedJobName=ko.observable();
                self.getCmpPairList = ko.observableArray([]);
                
                        self.jobSelectionChanged = function (data, event) {
                    self.getCmpPairList([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/selectjob",
                        type: 'POST',
                        data: JSON.stringify({
                            jobName: self.selectedJobName()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            for (var i = 0; i < data[0].length; i++) {
                                self.getCmpPairList.push({Pair_Name: data[0][i].PAIRNAME,Src_Con:data[0][i].SRCCONNNAME,Tgt_Con:data[0][i].TGTCONNNAME,Src_Schema:data[0][i].SRCSCHEMANAME,Src_Tab:data[0][i].SRCTABNAME,Tgt_Schema:data[0][i].TGTSCHEMANAME,Tgt_Tab:data[0][i].TGTTABNAME});
                            }
                            return self;
                        }

                    })
                }

                                self.CmpPairListDP = new oj.ArrayDataProvider(self.getCmpPairList, {keyAttributes: 'Pair_Name'});

                self.jobPairColArray = [{headerText: 'Pair Name ',
                        field: 'Pair_Name'},
                    {headerText: 'Source Connection',
                        field: 'Src_Con'},
                    {headerText: 'Target Connection',
                        field: 'Tgt_Con'},
                    {headerText: 'Source Schema',
                        field: 'Src_Schema'},
                    {headerText: 'Source Table Name',
                        field: 'Src_Tab'},
                    {headerText: 'Target Schema',
                        field: 'Tgt_Schema'},
                    {headerText: 'Taget Table Name',
                        field: 'Tgt_Tab'}
                ];

                self.pairJobRunMsg = ko.observable();
                
                self.jobRun = function (data, event) {
                    self.getCmpPairList([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/jobrun",
                        type: 'POST',
                        data: JSON.stringify({
                            jobName: self.selectedJobName(),
                            pairName : self.pairInfo()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                           
                           self.pairJobRunMsg(data[0]);
                            document.querySelector('#pairJobRun').open();
                           
                            return self;
                        }

                    })
                }

                self.pairItems = ko.observable({row: new keySet.KeySetImpl(), column: new keySet.KeySetImpl()});
                self.pairInfo = ko.observable('');
                self.pairSelectionMode = ko.observable({row: 'single', column: 'none'});

                self.pairSelectionMode.subscribe(function (newValue) {
                    // Reset selected Items on selection mode change.
                    self.pairItems({row: new keySet.KeySetImpl(), column: new keySet.KeySetImpl()});
                }.bind(this));

                self.pairChangedListener = function (event) {
                    var selectionText = '';

                    if (event.detail.value.row.isAddAll()) {
                        var iterator = event.detail.value.row.deletedValues();
                        iterator.forEach(function (key) {
                            selectionText = selectionText.length === 0 ? key : selectionText + ', ' + key;
                        });

                        if (iterator.size > 0) {
                            selectionText = ' except ' + selectionText;
                        }
                        selectionText = 'Row Selection:\nAll rows are selected' + selectionText;
                    } else {
                        if (event.detail.value.row.values().size > 0) {
                            event.detail.value.row.values().forEach(function (key) {
                                selectionText += (selectionText.length === 0 ? key : ', ' + key);
                            });
                            selectionText = selectionText;
                        }
                        if (event.detail.value.column.values().size > 0) {
                            event.detail.value.column.values().forEach(function (key) {
                                selectionText += (selectionText.length === 0 ? key : ', ' + key);
                            });
                            selectionText = 'Column Selection:\nColumn Keys: ' + selectionText;
                        }
                    }
                    self.pairInfo(selectionText);
                }.bind(this);



                self.pairJobOKClose = function (event) {
                    document.querySelector('#pairJobRun').close();
                     self.selectedJobName('');
                };

                self.cancel = function () {
                    oj.Router.rootInstance.go('compare');

                }

                self.connected = function () { 
                    if (sessionStorage.getItem("userName")==null) {
                        oj.Router.rootInstance.go('signin');
                    }
                    else
                    {
                      app.onAppSuccess();
                    }
        
                };

                /**
                 * Optional ViewModel method invoked after the View is disconnected from the DOM.
                 */
                self.disconnected = function () {
                    // Implement if needed
                };

                /**
                 * Optional ViewModel method invoked after transition to the new View is complete.
                 * That includes any possible animation between the old and the new View.
                 */
                self.transitionCompleted = function () {
                    // Implement if needed
                };
            }

            /*
             * Returns an instance of the ViewModel providing one instance of the ViewModel. If needed,
             * return a constructor for the ViewModel so that the ViewModel is constructed
             * each time the view is displayed.
             */
            return  CompJobViewModel;
        }
);
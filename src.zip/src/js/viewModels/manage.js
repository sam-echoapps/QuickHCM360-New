
define(['ojs/ojcore', 'knockout', 'jquery', 'appController',
    'ojs/ojtranslation', 'ojs/ojconverter-number', 'ojs/ojarraydataprovider', 'ojs/ojmasonrylayout', 'ojs/ojtable',
    'ojs/ojbutton', 'ojs/ojinputnumber', 'ojs/ojinputtext', 'ojs/ojdialog', 'ojs/ojmenu', 'ojs/ojoption', 'ojs/ojdialog',
    'ojs/ojselectcombobox', 'ojs/ojavatar', 'ojs/ojlabel', 'ojs/ojlabelvalue', 'ojs/ojprogress-bar', 'ojs/ojcheckboxset', 'ojs/ojformlayout', 'ojs/ojradioset'],
    function (oj, ko, $, app, Translations, NumberConverter, ArrayDataProvider) {

        class ManageViewModel {
            constructor(args) {
            var self = this;
            self.MgrName = ko.observable();
            self.ExtName = ko.observable();
            self.PmpName = ko.observable();
            self.RepName = ko.observable();
            self.maxRowsStretch = ko.observable();
            self.dynamicPortList = ko.observable();
            self.mgrPortCheck = ko.observable(true);
            self.dynamicPortListCheck = ko.observable(false);
            self.dynamicPortListCheckEnable = ko.observable(false);

            if (self.dynamicPortListCheckEnable == false) {
                self.dynamicPortListCheck == false;
            }

            self.MgrData1 = ko.observableArray([]);
            self.ExtData1 = ko.observableArray([]);
            self.PmpData1 = ko.observableArray([]);
            self.RepData1 = ko.observableArray([]);


            self.styleMgr = ko.observable();
            self.styleExt = ko.observable();
            self.stylePmp = ko.observable();
            self.styleRep = ko.observable();

            self.ExtATCSN = ko.observable();
            self.ExtAFTERCSN = ko.observable();
            self.RepATCSN = ko.observable();
            self.RepAFTERCSN = ko.observable();

            self.decimalHalfDownConverter =
                new NumberConverter.IntlNumberConverter({
                    style: 'decimal',
                    roundingMode: 'HALF_DOWN',
                    maximumFractionDigits: 0,
                    useGrouping: false
                });


            function refresh() {
                $.ajax({
                    url: "http://192.168.0.11:8080/gginfoall",
                    type: 'GET',
                    dataType: 'json',
                    context: self,
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {
                        self.MgrData1([]);
                        self.ExtData1([]);
                        self.PmpData1([]);
                        self.RepData1([]);
                        for (var i = 0; i < data[0].length; i++) { 
                        if (data[0][i].extstat == 'ABENDED') {
                            self.styleExt = { "background-color": "IndianRed" };
                            self.ExtData1.push({ ExtName: data[0][i].extname, ExtStat: data[0][i].extstat, ExtLag: data[0][i].extlag, ExtChkLag: data[0][i].extchklag, collapsedSizeClass: 'oj-masonrylayout-tile-1x1', expandedSizeClass: 'oj-masonrylayout-tile-1x2', expanded: ko.observable(false) });

                        } else if (data[0][i].extstat == 'STOPPED') {

                            self.styleExt = { "background-color": "Chocolate" };
                            self.ExtData1.push({ ExtName: data[0][i].extname, ExtStat: data[0][i].extstat, ExtLag: data[0][i].extlag, ExtChkLag: data[0][i].extchklag, collapsedSizeClass: 'oj-masonrylayout-tile-1x1', expandedSizeClass: 'oj-masonrylayout-tile-1x2', expanded: ko.observable(false)});

                        } else if (data[0][i].extstat == 'RUNNING') {
                            self.styleExt = { "background-color": "ForestGreen" };
                            self.ExtData1.push({ ExtName: data[0][i].extname, ExtStat: data[0][i].extstat, ExtLag: data[0][i].extlag, ExtChkLag: data[0][i].extchklag, collapsedSizeClass: 'oj-masonrylayout-tile-1x1', expandedSizeClass: 'oj-masonrylayout-tile-1x2', expanded: ko.observable(false)});
                        }
                        if (data[0][i].pmpstat == 'ABENDED') {
                            
                            self.stylePmp = { "background-color": "IndianRed" };
                            self.PmpData1.push({ PmpName: data[0][i].pmpname, PmpStat: data[0][i].pmpstat, PmpLag: data[0][i].pmplag, PmpChkLag: data[0][i].pmpchklag, collapsedSizeClass: 'oj-masonrylayout-tile-1x1', expandedSizeClass: 'oj-masonrylayout-tile-1x2', expanded: ko.observable(false) });

                        } else if (data[0][i].pmpstat == 'STOPPED') {

                            self.stylePmp = { "background-color": "Chocolate" };
                            self.PmpData1.push({ PmpName: data[0][i].pmpname, PmpStat: data[0][i].pmpstat, PmpLag: data[0][i].pmplag, PmpChkLag: data[0][i].pmpchklag, collapsedSizeClass: 'oj-masonrylayout-tile-1x1', expandedSizeClass: 'oj-masonrylayout-tile-1x2', expanded: ko.observable(false) });

                        } else if (data[0][i].pmpstat == 'RUNNING') {

                            self.stylePmp = { "background-color": "ForestGreen" };
                            self.PmpData1.push({ PmpName: data[0][i].pmpname, PmpStat: data[0][i].pmpstat, PmpLag: data[0][i].pmplag, PmpChkLag: data[0][i].pmpchklag, collapsedSizeClass: 'oj-masonrylayout-tile-1x1', expandedSizeClass: 'oj-masonrylayout-tile-1x2', expanded: ko.observable(false) });
                        }

                        if (data[0][i].repstat == 'ABENDED') {
                            self.styleRep = { "background-color": "IndianRed" };
                            self.RepData1.push({ RepName: data[0][i].repname, RepStat: data[0][i].repstat, RepLag: data[0][i].replag, RepChkLag: data[0][i].repchklag, collapsedSizeClass: 'oj-masonrylayout-tile-1x1', expandedSizeClass: 'oj-masonrylayout-tile-1x2', expanded: ko.observable(false) });
                        } else if (data[0][i].repstat == 'STOPPED') {

                            self.styleRep = { "background-color": "Chocolate" };
                            self.RepData1.push({ RepName: data[0][i].repname, RepStat: data[0][i].repstat, RepLag: data[0][i].replag, RepChkLag: data[0][i].repchklag, collapsedSizeClass: 'oj-masonrylayout-tile-1x1', expandedSizeClass: 'oj-masonrylayout-tile-1x2', expanded: ko.observable(false) });
                        } else if (data[0][i].repstat == 'RUNNING') {
                            self.styleRep = { "background-color": "ForestGreen" };
                            self.RepData1.push({ RepName: data[0][i].repname, RepStat: data[0][i].repstat, RepLag: data[0][i].replag, RepChkLag: data[0][i].repchklag, collapsedSizeClass: 'oj-masonrylayout-tile-1x1', expandedSizeClass: 'oj-masonrylayout-tile-1x2', expanded: ko.observable(false) });
                        }
                        
                        if (data[0][i].mgrstat == 'DOWN!') {
                                self.styleMgr = { "background-color": "IndianRed" };
                                self.MgrData1.push({ MgrName: 'Manager', MgrStat: data[0].mgrstat, collapsedSizeClass: 'oj-masonrylayout-tile-1x1', expandedSizeClass: 'oj-masonrylayout-tile-1x2', expanded: ko.observable(false) });
                            }
                            else if (data[0][i].mgrstat == 'running') {
                                self.styleMgr = { "background-color": "ForestGreen" };
                                self.MgrData1.push({ MgrName: 'Manager', MgrStat: data[0][i].mgrstat, collapsedSizeClass: 'oj-masonrylayout-tile-1x1', expandedSizeClass: 'oj-masonrylayout-tile-1x2', expanded: ko.observable(false) });
                            }
                        }
                        
                        return self;
                    }
                })

            }

            
            self.args = args;
            self.router = self.args.parentRouter;


            self.openExtractListener = function () {
                self.router.go({path : 'addextract'})
            };

            self.openPumpListener = function () {
                self.router.go({path : 'addextract'});
            };

            self.openReplicatListener = function () {
                self.router.go({path : 'addreplicat'});
            };




            self.handledMgrCollapse = false;
            self.handledExtCollapse = false;
            self.handledPmpCollapse = false;
            self.handledRepCollapse = false;

            var closestByClass = function (el, className) {
                while (!el.classList.contains(className)) {
                    // Increment the loop to the parent node
                    el = el.parentNode;
                    if (!el) {
                        return null;
                    }
                }
                return el;
            };


            self.MgrResizeTile = function (event, current) {
                var target = event.target;

                var tile = closestByClass(target, 'mgr-tile');
                var masonryLayout = closestByClass(tile, 'oj-masonrylayout');
                // get the data for the tile, which will be an item in the
                // chemicals array defined above
                var data = current.data;
                self.MgrName = current.data.MgrName;
                masonryLayout.resizeTile(
                    '#' + tile.getAttribute('id'),
                    data.expanded() ? data.collapsedSizeClass : data.expandedSizeClass);
            };

            // This listener is called before the tile is resized  for the Extract
            self.MgrHandleBeforeResize = function (event) {
                var tile = event.detail.tile;
                var context = ko.contextFor(tile);
                var data = context.$current.data;
                self.MgrName = context.$current.data.MgrName;
                // If the tile is being collapsed, hide the additional
                // expanded content before the tile is resized.
                if (data.expanded()) {
                    data.expanded(false);
                    // Remember that this resize is a collapse so that the
                    // "resize" event listener called after the tile is resized
                    // does not also try to handle the operation.
                    self.handledMgrCollapse = true;
                }
            };


            // This listener is called after the tile is resized  for the Extract
            self.MgrHandleResize = function (event) {
                // Only handle the event if the tile is being expanded.
                if (!self.handledMgrCollapse) {
                    var tile = event.detail.tile;
                    // get the ko binding context for the tile DOM element
                    var context = ko.contextFor(tile);
                    // get the data for the tile, which will be an item in the
                    // chemicals array defined above
                    var data = context.$current.data;

                    self.MgrName = context.$current.data.MgrName;
                    // If the tile is being expanded, show the additional
                    // content after the tile is resized.
                    if (!data.expanded()) {
                        data.expanded(true);
                    }
                }
                // Reset the flag for the next resize.
                self.handledMgrCollapse = false;
            };



            // This listener is called when the resize button in the tile
            // is clicked.
            self.ExtResizeTile = function (event, current) {
                var target = event.target;

                var tile = closestByClass(target, 'ext-tile');
                var masonryLayout = closestByClass(tile, 'oj-masonrylayout');
                // get the data for the tile, which will be an item in the
                // chemicals array defined above
                var data = current.data;
                self.ExtName = current.data.ExtName;
                masonryLayout.resizeTile(
                    '#' + tile.getAttribute('id'),
                    data.expanded() ? data.collapsedSizeClass : data.expandedSizeClass);
            };

            // This listener is called before the tile is resized  for the Extract
            self.ExtHandleBeforeResize = function (event) {
                var tile = event.detail.tile;
                var context = ko.contextFor(tile);
                var data = context.$current.data;
                self.ExtName = context.$current.data.ExtName;
                // If the tile is being collapsed, hide the additional
                // expanded content before the tile is resized.
                if (data.expanded()) {
                    data.expanded(false);
                    // Remember that this resize is a collapse so that the
                    // "resize" event listener called after the tile is resized
                    // does not also try to handle the operation.
                    self.handledExtCollapse = true;
                }
            };


            // This listener is called after the tile is resized  for the Extract
            self.ExtHandleResize = function (event) {
                // Only handle the event if the tile is being expanded.
                if (!self.handledExtCollapse) {
                    var tile = event.detail.tile;
                    // get the ko binding context for the tile DOM element
                    var context = ko.contextFor(tile);
                    // get the data for the tile, which will be an item in the
                    // chemicals array defined above
                    var data = context.$current.data;

                    self.ExtName = context.$current.data.ExtName;
                    // If the tile is being expanded, show the additional
                    // content after the tile is resized.
                    if (!data.expanded()) {
                        data.expanded(true);
                    }
                }
                // Reset the flag for the next resize.
                self.handledExtCollapse = false;
            };


            // This listener is called when the resize button in the tile
            // is clicked.
            self.PmpResizeTile = function (event, current) {
                var target = event.target;

                var tile = closestByClass(target, 'pmp-tile');
                var masonryLayout = closestByClass(tile, 'oj-masonrylayout');
                // get the data for the tile, which will be an item in the
                // chemicals array defined above
                var data = current.data;
                self.PmpName = current.data.PmpName;
                masonryLayout.resizeTile(
                    '#' + tile.getAttribute('id'),
                    data.expanded() ? data.collapsedSizeClass : data.expandedSizeClass);
            };

            // This listener is called before the tile is resized for thre Pump.
            self.PmpHandleBeforeResize = function (event) {
                var tile = event.detail.tile;
                var context = ko.contextFor(tile);
                var data = context.$current.data;
                self.PmpName = context.$current.data.PmpName;
                // If the tile is being collapsed, hide the additional
                // expanded content before the tile is resized.
                if (data.expanded()) {
                    data.expanded(false);
                    // Remember that this resize is a collapse so that the
                    // "resize" event listener called after the tile is resized
                    // does not also try to handle the operation.
                    self.handledPmpCollapse = true;
                }
            };

            // This listener is called after the tile is resized  for the Pump
            self.PmpHandleResize = function (event) {
                // Only handle the event if the tile is being expanded.
                if (!self.handledPmpCollapse) {
                    var tile = event.detail.tile;
                    // get the ko binding context for the tile DOM element
                    var context = ko.contextFor(tile);
                    // get the data for the tile, which will be an item in the
                    // chemicals array defined above
                    var data = context.$current.data;

                    self.PmpName = context.$current.data.PmpName;
                    // If the tile is being expanded, show the additional
                    // content after the tile is resized.
                    if (!data.expanded()) {
                        data.expanded(true);
                    }
                }
                // Reset the flag for the next resize.
                self.handledPmpCollapse = false;
            };

            self.RepResizeTile = function (event, current) {
                var target = event.target;

                var tile = closestByClass(target, 'rep-tile');
                var masonryLayout = closestByClass(tile, 'oj-masonrylayout');
                // get the data for the tile, which will be an item in the
                // chemicals array defined above
                var data = current.data;
                self.RepName = current.data.RepName;
                masonryLayout.resizeTile(
                    '#' + tile.getAttribute('id'),
                    data.expanded() ? data.collapsedSizeClass : data.expandedSizeClass);
            };

            // This listener is called before the tile is resized for Replicat.
            self.RepHandleBeforeResize = function (event) {
                var tile = event.detail.tile;
                var context = ko.contextFor(tile);
                var data = context.$current.data;
                self.RepName = context.$current.data.RepName;
                // If the tile is being collapsed, hide the additional
                // expanded content before the tile is resized.
                if (data.expanded()) {
                    data.expanded(false);
                    // Remember that this resize is a collapse so that the
                    // "resize" event listener called after the tile is resized
                    // does not also try to handle the operation.
                    self.handledRepCollapse = true;
                }
            };

            // This listener is called after the tile is resized for the Replicat.
            self.RepHandleResize = function (event) {
                // Only handle the event if the tile is being expanded.
                if (!self.handledRepCollapse) {
                    var tile = event.detail.tile;
                    // get the ko binding context for the tile DOM element
                    var context = ko.contextFor(tile);
                    // get the data for the tile, which will be an item in the
                    // chemicals array defined above
                    var data = context.$current.data;

                    self.RepName = context.$current.data.RepName;
                    // If the tile is being expanded, show the additional
                    // content after the tile is resized.
                    if (!data.expanded()) {
                        data.expanded(true);
                    }
                }
                // Reset the flag for the next resize.
                self.handledRepCollapse = false;
            };


            //Manager

            self.getMgrTileId = function (index) {
                return 'mgr-tile' + (index + 1);
            };

            self.getMgrLabelId = function (index) {
                return 'mgr-label' + (index + 1);
            };

            self.getMgrButtonId = function (index) {
                return 'mgr-resizeButton' + (index + 1);
            };

            self.getMgrButtonLabelledBy = function (index) {
                return self.getMgrButtonId(index) + ' ' + self.getMgrLabelId(index);
            };

            self.getMgrButtonLabel = function (data) {
                return data.expanded() ?
                    Translations.getTranslatedString(
                        'oj-panel.labelAccButtonCollapse') :
                    Translations.getTranslatedString(
                        'oj-panel.labelAccButtonExpand');
            };

            self.getMgrButtonIcon = function (data) {
                return {
                    'oj-panel-expand-icon': !data.expanded(),
                    'oj-panel-collapse-icon': data.expanded()
                };
            };


            //Extract
            self.getExtTileId = function (index) {
                return 'ext-tile' + (index + 1);
            };

            self.getExtLabelId = function (index) {
                return 'ext-label' + (index + 1);
            };

            self.getExtButtonId = function (index) {
                return 'ext-resizeButton' + (index + 1);
            };

            self.getExtButtonLabelledBy = function (index) {
                return self.getExtButtonId(index) + ' ' + self.getExtLabelId(index);
            };

            self.getExtButtonLabel = function (data) {
                return data.expanded() ?
                    Translations.getTranslatedString(
                        'oj-panel.labelAccButtonCollapse') :
                    Translations.getTranslatedString(
                        'oj-panel.labelAccButtonExpand');
            };

            self.getExtButtonIcon = function (data) {
                return {
                    'oj-panel-expand-icon': !data.expanded(),
                    'oj-panel-collapse-icon': data.expanded()
                };
            };


            //Pump 

            self.getPmpTileId = function (index) {
                return 'pmp-tile' + (index + 1);
            };

            self.getPmpLabelId = function (index) {
                return 'pmp-label' + (index + 1);
            };

            self.getPmpButtonId = function (index) {
                return 'pmp-resizeButton' + (index + 1);
            };

            self.getPmpButtonLabelledBy = function (index) {
                return self.getPmpButtonId(index) + ' ' + self.getPmpLabelId(index);
            };

            self.getPmpButtonLabel = function (data) {
                return data.expanded() ?
                    Translations.getTranslatedString(
                        'oj-panel.labelAccButtonCollapse') :
                    Translations.getTranslatedString(
                        'oj-panel.labelAccButtonExpand');
            };

            self.getPmpButtonIcon = function (data) {
                return {
                    'oj-panel-expand-icon': !data.expanded(),
                    'oj-panel-collapse-icon': data.expanded()
                };
            };




            self.getRepTileId = function (index) {
                return 'rep-tile' + (index + 1);
            };

            self.getRepLabelId = function (index) {
                return 'rep-label' + (index + 1);
            };

            self.getRepButtonId = function (index) {
                return 'rep-resizeButton' + (index + 1);
            };

            self.getRepButtonLabelledBy = function (index) {
                return self.getRepButtonId(index) + ' ' + self.getRepLabelId(index);
            };

            self.getRepButtonLabel = function (data) {
                return data.expanded() ?
                    Translations.getTranslatedString(
                        'oj-panel.labelAccButtonCollapse') :
                    Translations.getTranslatedString(
                        'oj-panel.labelAccButtonExpand');
            };

            self.getRepButtonIcon = function (data) {
                return {
                    'oj-panel-expand-icon': !data.expanded(),
                    'oj-panel-collapse-icon': data.expanded()
                };
            };



            self.CancelBehaviorOpt = ko.observable('icon');

            self.username1 = ko.observableArray([]);
            self.aliasname1 = ko.observableArray([]);
            self.domname1 = ko.observableArray([]);
            self.othdom = ko.observableArray([]);
            self.alias = ko.observable();
            self.user = ko.observable();
            self.valdom = ko.observable();
            self.uName = ko.observable();
            self.uPasswd = ko.observable();
            self.uRepPass = ko.observable();
            self.selectedAliascategory = ko.observable();
            self.selectedUsercategory = ko.observable();
            self.aliascategories = ko.observableArray([]);
            self.unamecategories = ko.observable();
            self.selectedDomCategory = ko.observable();

            function getDomains() {
                self.username1([]);
                self.othdom([]);
                self.aliasname1([]);
                self.domname1([]);
                self.selectedAliascategory('');
                self.selectedUsercategory('');
                self.uRepPass()
                self.uName('');
                self.uPasswd('');
                self.uRepPass('');
                self.valdom('')
                $.ajax({
                    url: "http://192.168.0.11:8080/ggcredstore",
                    type: 'GET',
                    dataType: 'json',
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {

                        for (var i = 0; i < data[1].length; i++) {
                            self.othdom.push({ dom: data[1][i].value });
                        }

                        self.aliasname1(data[4]);


                        for (var i = 0; i < data[2].length; i++) {
                            self.domname1.push({ label: data[2][i], value: data[2][i] });
                        }

                        for (var i = 0; i < data[0].length; i++) {
                            self.username1.push({ label: data[0][i].alias, value: data[0][i].alias, 'children': [{ label: data[0][i].uname, value: data[0][i].uname }] });
                        }
                        console.log(self)

                        return self;
                    }
                })
            }


            let getAliascategories = (category) => {
                let found = self.aliasname1().find(c => c.value === category);
                return found ? found.children : null;
            };
            let getUnamecategories = (category) => {
                let found = self.username1().find(c => c.value === category);
                return found ? found.children : null;
            };
            this.domSelectionChanged = (event) => {
                self.selectedAliascategory('');
                let children = getAliascategories(event.detail.value);
                self.aliascategories(children);
            };


            self.aliasSelectionChanged = (event) => {
                self.selectedUsercategory('');
                let children = getUnamecategories(event.detail.value);
                self.unamecategories(children);
            };


            self.isRequired = ko.observable(true);
            self.checkboxValues = ko.observableArray(['required', 'helpSource', 'helpDef']);

            self.isRequired = ko.computed(function () {
                return self.checkboxValues.indexOf('required') !== -1;
            });
            self.helpDef = ko.computed(function () {
                return (self.checkboxValues.indexOf('helpDef') !== -1) ? self._HELP_DEF : null;
            });
            this.helpSource = ko.computed(function () {
                return (self.checkboxValues.indexOf('helpSource') !== -1) ? self._HELP_SOURCE : null;
            });

            var data;
            var params = {
                url: "http://192.168.0.11:8080/ggmgrops",
                type: 'POST',
                dataType: 'json',
                data: data,
                context: self,
                error: function (e) {
                    console.log(e);
                },
                success: function (data) {
                    document.querySelector('#ViewMgrRptDialog').open();
                    self.MgrRpt(data[0]);
                    console.log(self);
                    return self;
                }
            }

            //Manager Functions
            self.MgrRpt = ko.observableArray([]);
            self.selectedMgrMenuItem = ko.observable('');

            self.menuMgrItemAction = function (event) {
                self.selectedMgrMenuItem(event.target.value);
                //Extract Report File
                if (self.selectedMgrMenuItem() == 'mgrrpt') {
                    self.MgrRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/viewmgrrpt",
                        type: 'GET',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewMgrRptDialog').open();
                            self.MgrRpt(data[0]);
                            console.log(self);
                            return self;

                        }

                    })
                }
                else if (self.selectedMgrMenuItem() == 'mgredit') {
                    self.mgrPrmRead([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/readmgrprm",
                        type: 'GET',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#EditMgrDialog').open();
                            self.mgrPrmRead(data[0]);
                            console.log(self);
                            return self;
                        }
                    })
                }
                else if (self.selectedMgrMenuItem() == 'mgrstart') {
                    self.MgrRpt([]);
                    params.data = JSON.stringify({
                        mgrOps: 'START'
                    })
                    $.ajax(params)
                }
                else if (self.selectedMgrMenuItem() == 'mgrstop') {
                    document.querySelector('#StopMgrDialog').open();
                }

                else if (self.selectedMgrMenuItem() == 'mgrkill') {
                    document.querySelector('#KillMgrDialog').open();
                }
                else if (self.selectedMgrMenuItem() == 'mgrrefresh') {
                    self.MgrRpt([]);
                    params.data = JSON.stringify({
                        mgrOps: 'REFRESH'
                    })
                    $.ajax(params)
                }
            }
            self.ViewMgrRptOKClose = function (event) {
                refresh();
                document.querySelector('#ViewMgrRptDialog').close();
            };



            self.mgrPrmRead = ko.observable();
            self.mgrPrmWrite = ko.observable();


            self.stopMgr = function (event, data) {
                self.MgrRpt([]);
                document.querySelector('#StopMgrDialog').close();
                params.data = JSON.stringify({
                    mgrOps: 'STOP'
                })
                $.ajax(params)
            }


            self.killMgr = function (event, data) {
                self.MgrRpt([]);
                document.querySelector('#KillMgrDialog').close();
                params.data = JSON.stringify({
                    mgrOps: 'KILL'
                })
                $.ajax(params)
            }

            self.saveMgrPrm = function (event, data) {
                $.ajax({
                    url: "http://192.168.0.11:8080/writemgrprm",
                    type: 'POST',
                    dataType: 'json',
                    data: JSON.stringify({
                        currentMgrParams: self.mgrPrmWrite()
                    }),
                    context: self,
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {
                        document.querySelector('#EditMgrDialog').close();
                        document.querySelector('#ViewMgrRptDialog').open();
                        self.MgrRpt(data[0]);
                        return self;
                    }
                })
            }

            // Extract Functions

            self.ExtRpt = ko.observableArray([]);
            self.addExtTrailName = ko.observable();
            self.addExtTrailType = ko.observable('exttrail');
            self.addExtTrailSize = ko.observable('500')

            self.selectedMenuItem = ko.observable();
            self.ExtOpenTrans = ko.observableArray([]);

            function getOpenTrans() {
                document.querySelector('#FetchOpenTrans').open();
                self.ExtOpenTrans([]);
                $.ajax({
                    url: "http://192.168.0.11:8080/ggextshowtrans",
                    data: JSON.stringify({
                        extname: self.ExtName
                    }),
                    type: 'POST',
                    dataType: 'json',
                    context: self,
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {
                        self.ExtOpenTrans(data[0]);
                        document.querySelector('#FetchOpenTrans').close();
                        return self;
                    }
                })
            }

            self.menuItemAction = function (event) {
                self.selectedMenuItem(event.target.value);
                //Extract Report File
                if (self.selectedMenuItem() == 'extrpt') {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/viewextrpt",
                        data: JSON.stringify({
                            extname: self.ExtName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                            self.ExtRpt(data[0]);
                            console.log(self);
                            return self;

                        }

                    })
                }
                //Extract Checkpoint 
                else if (self.selectedMenuItem() == 'extchk') {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/viewextchk",
                        data: JSON.stringify({
                            extname: self.ExtName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();

                            self.ExtRpt(data[0]);
                            console.log(self);
                            return self;

                        }

                    })
                }
                //Extract Stats  
                else if (self.selectedMenuItem() == 'extstats') {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/extstats",
                        data: JSON.stringify({
                            extname: self.ExtName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();

                            self.ExtRpt(data[0]);

                            return self;

                        }

                    })
                }
                //Extract Start Default  
                else if (self.selectedMenuItem() == 'extstartdef') {
                    document.querySelector('#startExtractDiaglog').open();
                    self.ExtRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/extstart",
                        data: JSON.stringify({
                            extname: self.ExtName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#startExtractDiaglog').close();
                            document.querySelector('#ViewExtractRptDialog').open();
                            self.ExtRpt(data[0]);
                            return self;

                        }

                    })
                }
                //Extract Start ATCSN  
                else if (self.selectedMenuItem() == 'extatcsn') {
                    self.ExtATCSN();
                    document.querySelector('#ExtractATCSNDialog').open();

                }
                //Extract Start After CSN  
                else if (self.selectedMenuItem() == 'extaftercsn') {
                    self.ExtAFTERCSN(0);
                    document.querySelector('#ExtractAFTERCSNDialog').open();

                }
                //Extract Stop
                else if (self.selectedMenuItem() == 'extstop') {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/extstop",
                        data: JSON.stringify({
                            extname: self.ExtName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                            self.ExtRpt(data[0]);
                            getDomains();
                            return self;

                        }

                    })
                }
                //Extract Force Stop
                else if (self.selectedMenuItem() == 'extforcestop') {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/extforcestop",
                        data: JSON.stringify({
                            extname: self.ExtName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                            self.ExtRpt(data[0]);
                            return self;

                        }

                    })
                }
                //Extract Kill
                else if (self.selectedMenuItem() == 'extkill') {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/extkill",
                        data: JSON.stringify({
                            extname: self.ExtName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                            self.ExtRpt(data[0]);
                            return self;

                        }

                    })
                }
                //Extract Upgrade to IE 
                else if (self.selectedMenuItem() == 'upgie') {
                    getDomains();
                    document.querySelector('#ExtLoginDialog').open();
                }
                //Extract Delete
                else if (self.selectedMenuItem() == 'delext') {
                    getDomains();
                    document.querySelector('#ExtLoginDialog').open();
                }
                else if (self.selectedMenuItem() == 'cachemgr') {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/ggviewcomstats",
                        data: JSON.stringify({
                            extname: self.ExtName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                            self.ExtRpt(data[0]);
                            return self;
                        }
                    })
                }
                else if (self.selectedMenuItem() == 'extshowtrans') {
                    document.querySelector('#ViewExtOpenTransDialog').open();
                    getOpenTrans();
                }
                else if (self.selectedMenuItem() == 'extstatus') {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/ggextstatus",
                        data: JSON.stringify({
                            extname: self.ExtName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                            self.ExtRpt(data[0]);
                            return self;
                        }
                    })
                }

                else if (self.selectedMenuItem() == 'delexttrail') {
                    document.querySelector('#GettingTrailName').open();
                    self.ExtRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/getexttrailname",
                        data: JSON.stringify({
                            extname: self.ExtName,
                            trailname : self.ExtRpt()
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#GettingTrailName').close();
                            document.querySelector('#TrailForDelete').open();
                            self.ExtRpt(data[0]);
                            return self;
                        }
                    })
                }

                else if (self.selectedMenuItem() == 'addexttrail') {
                    document.querySelector('#AddExtTrailDialog').open();
                                 }
            }

            self.DeleteTrailOKClose = function (event) {
                document.querySelector('#TrailForDelete').close();
                document.querySelector('#GettingTrailName').open();
                $.ajax({
                    url: "http://192.168.0.11:8080/delexttrail",
                    data: JSON.stringify({
                        extname: self.ExtName,
                        trailname : self.ExtRpt()
                    }),
                    type: 'POST',
                    dataType: 'json',
                    context: self,
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {
                        document.querySelector('#GettingTrailName').close();
                        document.querySelector('#DeleteTrail').open();
                        self.ExtRpt(data[0]);
                        return self;
                    }
                })
            };

            self.AddExtTrail = function (event,data) {
                document.querySelector('#GettingTrailName').open();
                $.ajax({
                    url: "http://192.168.0.11:8080/addexttrail",
                    data: JSON.stringify({
                        extname : self.ExtName,
                        trailname : self.addExtTrailName(),
                        trailtype : self.addExtTrailType(),
                        trailsize : self.addExtTrailSize()
                    }),
                    type: 'POST',
                    dataType: 'json',
                    context: self,
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {
                        document.querySelector('#GettingTrailName').close();
                        document.querySelector('#ViewExtractRptDialog').open();
                        self.ExtRpt(data[0]);
                        return self;
                    }
                })
            };

            self.TrailOKClose = function (event) {
                document.querySelector('#DeleteTrail').close();
            }

            self.showTransDP = new ArrayDataProvider(self.ExtOpenTrans, { keyAttributes: 'XID' });

            self.showTranscolumnArray = [
                {
                    headerText: 'Transaction ID',
                    field: 'XID'
                },
                {
                    headerText: '# of Records',
                    field: 'Items'
                },
                {
                    headerText: 'Extract Name',
                    field: 'Extract'
                },
                {
                    headerText: 'Redo Thread',
                    field: 'Redo Thread'
                },
                {
                    headerText: 'Start Time',
                    field: 'Start Time'
                },
                {
                    headerText: 'SCN',
                    field: 'SCN'
                },
                {
                    headerText: 'Redo Sequence',
                    field: 'Redo Seq'
                },
                {
                    headerText: 'Redo RBA',
                    field: 'Redo RBA'
                },
                {
                    headerText: 'Status',
                    field: 'Status'
                },
                {
                    headerText: "Action",
                    headerStyle: "text-align: center;",
                    style: "text-align: center; padding-top: 0px; padding-bottom: 0px;",
                    template: "actionTemplate"
                }
            ]

            self.actionListener = function (event) {
                event.detail.originalEvent.stopPropagation();
            };
            self.xid = ko.observable();

            self.menuListener = function (event, context) {
                self.xid('');
                var rowIndex = self.ExtRpt.indexOf(context.row);
                self.xid(context.row.XID);
                if (event.target.value === 'skiptrans') {
                    self.ExtRpt.splice(rowIndex, 1);
                    self.ExtRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/ggextskiptrans",
                        data: JSON.stringify({
                            extname: self.ExtName,
                            xid: self.xid()
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtTransSkipRpt').open();
                            self.ExtRpt(data[0]);
                            return self;
                        }
                    })
                }
            };


            self.ViewExtractRptOKClose = function (event) {
                refresh();
                document.querySelector('#ViewExtractRptDialog').close();
                document.querySelector('#ExtLoginDialog').close();
                document.querySelector('#AddExtTrailDialog').close();
            };

            self.ViewExtOpenTransrefresh = function (event) {
                getOpenTrans();
                self.ExtOpenTrans.valueHasMutated();
            }

            self.ViewExtTransSkipRptOKClose = function (event) {
                getOpenTrans();
                self.ExtOpenTrans.valueHasMutated();
                document.querySelector('#ViewExtTransSkipRpt').close();
            };



            self.ExtStartATCSN = function (data, event) {
                {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/extstartatcsn",
                        data: JSON.stringify({
                            extname: self.ExtName,
                            extatcsn: self.ExtATCSN()
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                            self.ExtRpt(data[0]);
                            document.querySelector('#ExtractATCSNDialog').close();
                            return self;

                        }

                    })
                }
            }



            self.ExtStartAFTERCSN = function (data, event) {
                self.ExtRpt([]);
                $.ajax({
                    url: "http://192.168.0.11:8080/extstartaftercsn",
                    data: JSON.stringify({
                        extname: self.ExtName,
                        extaftercsn: self.ExtAFTERCSN()
                    }),
                    type: 'POST',
                    dataType: 'json',
                    context: self,
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {
                        document.querySelector('#ViewExtractRptDialog').open();
                        self.ExtRpt(data[0]);
                        document.querySelector('#ExtractAFTERCSNDialog').close();
                        return self;

                    }

                })
            }


            self.ExtUpgTOIE = function (data, event) {
                self.ExtRpt([]);
                document.querySelector('#UpgExtractDialog').open();

                $.ajax({
                    url: "http://192.168.0.11:8080/extupgie",
                    data: JSON.stringify({
                        extname: self.ExtName,
                        domain: self.selectedDomCategory(),
                        alias: self.selectedAliascategory()
                    }),
                    type: 'POST',
                    dataType: 'json',
                    context: self,
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {
                        document.querySelector('#UpgExtractDialog').close();
                        document.querySelector('#ViewExtractRptDialog').open();
                        self.ExtRpt(data[0]);

                        return self;
                    }

                })
            }


            self.DelExt = function (data, event) {
                self.ExtRpt([]);
                $.ajax({
                    url: "http://192.168.0.11:8080/delext",
                    data: JSON.stringify({
                        extname: self.ExtName,
                        domain: self.selectedDomCategory(),
                        alias: self.selectedAliascategory()
                    }),
                    type: 'POST',
                    dataType: 'json',
                    context: self,
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {
                        document.querySelector('#ViewExtractRptDialog').open();
                        self.ExtRpt(data[0]);
                        return self;
                    }

                })
            }

            //Pump Functions

            self.PmpRpt = ko.observableArray([]);

            self.selectedPmpMenuItem = ko.observable('');

            self.menuPmpItemAction = function (event) {
                self.selectedPmpMenuItem(event.target.value);
                if (self.selectedPmpMenuItem() == 'pmprpt') {
                    self.PmpRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/viewextrpt",
                        data: JSON.stringify({
                            extname: self.PmpName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewPumpRptDialog').open();
                            self.PmpRpt(data[0]);
                            console.log(self);
                            return self;

                        }

                    })
                }
                else if (self.selectedPmpMenuItem() == 'pmpchk') {
                    self.PmpRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/viewextchk",
                        data: JSON.stringify({
                            extname: self.PmpName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewPumpRptDialog').open();

                            self.PmpRpt(data[0]);
                            console.log(self);
                            return self;

                        }

                    })
                }
                else if (self.selectedPmpMenuItem() == 'pmpstats') {
                    self.PmpRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/extstats",
                        data: JSON.stringify({
                            extname: self.PmpName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewPumpRptDialog').open();

                            self.PmpRpt(data[0]);

                            return self;

                        }

                    })
                }
                else if (self.selectedPmpMenuItem() == 'pmpstartdef') {
                    self.PmpRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/extstart",
                        data: JSON.stringify({
                            extname: self.PmpName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewPumpRptDialog').open();
                            self.PmpRpt(data[0]);
                            return self;

                        }

                    })
                }

                else if (self.selectedPmpMenuItem() == 'pmpstop') {
                    self.PmpRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/extstop",
                        data: JSON.stringify({
                            extname: self.PmpName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewPumpRptDialog').open();
                            self.PmpRpt(data[0]);
                            getDomains();
                            return self;

                        }

                    })
                }

                else if (self.selectedPmpMenuItem() == 'pmpstatus') {
                    self.PmpRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/ggextstatus",
                        data: JSON.stringify({
                            extname: self.PmpName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewPumpRptDialog').open();
                            self.PmpRpt(data[0]);
                            return self;
                        }
                    })
                }
                else if (self.selectedPmpMenuItem() == 'delrmt') {
                    document.querySelector('#DeleteConfirm').open();

                }

            }

            self.DeleteRMTOKClose = function (data, event) {
                self.PmpRpt([]);
                $.ajax({
                    url: "http://192.168.0.11:8080/ggdelrmt",
                    data: JSON.stringify({
                        pmpName: self.PmpName
                    }),
                    type: 'POST',
                    dataType: 'json',
                    context: self,
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {
                        document.querySelector('#ViewPumpRptDialog').open();

                        self.PmpRpt(data[0]);

                        return self;

                    }

                })
            }


            self.ViewPumpRptOKClose = function (event) {
                refresh();
                document.querySelector('#ViewPumpRptDialog').close();
                document.querySelector('#DeleteConfirm').close();
            };

            // Replicat Functions

            self.RepRpt = ko.observableArray([]);
            self.selectedRepMenuItem = ko.observable('');

            self.menuRepItemAction = function (event) {
                self.selectedRepMenuItem(event.target.value);
                if (self.selectedRepMenuItem() == 'reprpt') {
                    self.RepRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/viewreprpt",
                        data: JSON.stringify({
                            repname: self.RepName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewReplicatRptDialog').open();
                            self.RepRpt(data[0]);
                            console.log(self);
                            return self;

                        }

                    })
                }
                else if (self.selectedRepMenuItem() == 'repstats') {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/repstats",
                        data: JSON.stringify({
                            repname: self.RepName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewReplicatRptDialog').open();

                            self.RepRpt(data[0]);

                            return self;

                        }

                    })
                }
                else if (self.selectedRepMenuItem() == 'delrep') {
                    getDomains();
                    document.querySelector('#RepLoginDialog').open();
                }
                else if (self.selectedRepMenuItem() == 'repstartdef') {
                    self.RepRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/repstart",
                        data: JSON.stringify({
                            repname: self.RepName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewReplicatRptDialog').open();
                            self.RepRpt(data[0]);
                            return self;

                        }

                    })
                }
                else if (self.selectedRepMenuItem() == 'repstop') {
                    self.RepRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/repstop",
                        data: JSON.stringify({
                            repname: self.RepName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewReplicatRptDialog').open();
                            self.RepRpt(data[0]);
                            getDomains();
                            return self;

                        }

                    })
                }
                else if (self.selectedRepMenuItem() == 'repforcestop') {
                    self.RepRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/repforcestop",
                        data: JSON.stringify({
                            repname: self.RepName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewReplicatRptDialog').open();
                            self.RepRpt(data[0]);
                            getDomains();
                            return self;

                        }

                    })
                }

                else if (self.selectedRepMenuItem() == 'repkill') {
                    self.RepRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/repkill",
                        data: JSON.stringify({
                            repname: self.RepName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewReplicatRptDialog').open();
                            self.RepRpt(data[0]);
                            getDomains();
                            return self;

                        }

                    })
                }
                else if (self.selectedRepMenuItem() == 'repchk') {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/viewrepchk",
                        data: JSON.stringify({
                            repname: self.RepName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewReplicatRptDialog').open();

                            self.RepRpt(data[0]);
                            console.log(self);
                            return self;

                        }

                    })
                }
            }


            self.DelRep = function (data, event) {
                self.RepRpt([]);
                $.ajax({
                    url: "http://192.168.0.11:8080/delrep",
                    data: JSON.stringify({
                        repname: self.RepName,
                        domain: self.selectedDomCategory(),
                        alias: self.selectedAliascategory()
                    }),
                    type: 'POST',
                    dataType: 'json',
                    context: self,
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {
                        document.querySelector('#ViewReplicatRptDialog').open();
                        self.RepRpt(data[0]);
                        getDomains();
                        return self;
                    }

                })
            }

            self.ViewReplicatRptOKClose = function (event) {
                refresh();
                document.querySelector('#ViewReplicatRptDialog').close();
                document.querySelector('#RepLoginDialog').close();
            };

            console.log(self);

            self.RepStartATCSN = function (data, event) {
                {
                    self.RepRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/repstartatcsn",
                        data: JSON.stringify({
                            repname: self.RepName,
                            repatcsn: self.RepATCSN()
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewReplicatRptDialog').open();
                            self.RepRpt(data[0]);
                            document.querySelector('#ReplicatATCSNDialog').close();
                            getDomains();
                            return self;

                        }

                    })
                }
            }



            self.RepStartAFTERCSN = function (data, event) {
                self.RepRpt([]);
                $.ajax({
                    url: "http://192.168.0.11:8080/repstartaftercsn",
                    data: JSON.stringify({
                        repname: self.RepName,
                        repaftercsn: self.RepAFTERCSN()
                    }),
                    type: 'POST',
                    dataType: 'json',
                    context: self,
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {
                        document.querySelector('#ViewReplicatRptDialog').open();
                        self.RepRpt(data[0]);
                        document.querySelector('#ReplicatAFTERCSNDialog').close();
                        getDomains();
                        return self;

                    }

                })
            }





            self.connected = function () {
                if (sessionStorage.getItem("userName") == null) {
                    router.go('signin');
                }
                else {
                    app.onAppSuccess();
                    refresh();
                }
            }

            /**
             * Optional ViewModel method invoked after the View is disconnected from the DOM.
             */
            self.disconnected = function () {
                // Implement if needed
            };

            /**
             * Optional ViewModel method invoked after transition to the new View is complete.
             * That includes any possible animation between the old and the new View.
             */
            self.transitionCompleted = function () {

            };

        }

    }
        /*
         * Returns a constructor for the ViewModel so that the ViewModel is constructed
         * each time the view is displayed.  Return an instance of the ViewModel if
         * only one instance of the ViewModel is needed.
         */
        return  ManageViewModel;
    }
);

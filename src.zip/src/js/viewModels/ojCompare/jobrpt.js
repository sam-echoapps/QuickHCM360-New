define(['ojs/ojcore', 'knockout', 'jquery','appController' , 'ojs/ojkeyset','ojs/ojknockout',  'ojs/ojbutton', 'ojs/ojlabelvalue', 'ojs/ojlabel', 'ojs/ojformlayout', 'ojs/ojinputtext', 'ojs/ojselectsingle', 'ojs/ojselectcombobox', 'ojs/ojdialog','ojs/ojtable', 'ojs/ojpagingcontrol','ojs/ojchart'],
        function (oj, ko, $, app , keySet) {
            
    function CompJobViewModel() {
                var self = this;
                        this._HELP_SOURCE = 'http://www.oracle.com';
                        this._HELP_DEF = 'hostname.domainname:dbport/dbservice';

                this.isRequired = ko.observable(true);
                this.checkboxValues = ko.observableArray(['required', 'helpSource', 'helpDef']);

                this.isRequired = ko.computed(function () {
                    return this.checkboxValues.indexOf('required') !== -1;
                }.bind(this));
                this.helpDef = ko.computed(function () {
                    return (this.checkboxValues.indexOf('helpDef') !== -1) ? this._HELP_DEF : null;
                }.bind(this));
                this.helpSource = ko.computed(function () {
                    return (this.checkboxValues.indexOf('helpSource') !== -1) ? this._HELP_SOURCE : null;
                }.bind(this));

                this.isFormReadonly = ko.observable(false);
                self.jobName = ko.observable();

    self.jobNameList = ko.observableArray([]);

                function jobList() {
                    self.jobNameList([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/joblist",
                        type: 'GET',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {

                            for (var i = 0; i < data[0].length; i++) {

                                self.jobNameList.push({label: data[0][i].JOBNAME, value: data[0][i].JOBNAME});
                            }

                            console.log(self);
                            return self;
                        }

                    })

                }

                jobList();
                
                self.selectedJobName=ko.observable();
                self.getJobIDList = ko.observableArray([]);
                
                self.selectedJobID=ko.observable();
                
                        self.jobSelectionChanged = function (data, event) {
                                                self.jobIDRpt([]);
                    self.getJobIDList([]);
                    self.selectedJobID('')
                    $.ajax({
                        url: "http://192.168.0.11:8080/jobid",
                        type: 'POST',
                        data: JSON.stringify({
                            jobName: self.selectedJobName()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            for (var i = 0; i < data[0].length; i++) {
                                self.getJobIDList.push({label : data[0][i].ID, value : data[0][i].ID });
                            }
                            return self;
                        }

                    })
                }

                                


                self.jobIDRpt = ko.observableArray([]);
                
                
                self.jobIDSelectionChanged = function (data, event) {
                    self.jobIDRpt([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/jobidrpt",
                        type: 'POST',
                        data: JSON.stringify({
                            jobName: self.selectedJobName(),
                            jobID  : self.selectedJobID()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                         for (var i = 0; i < data[0].length; i++) {   
                           self.jobIDRpt.push({'Pair_Name' : data[0][i].PAIRNAME,'Job_ID':data[0][i].ID , 'Start_Time' : data[0][i].START_TIME,'End_Time':data[0][i].END_TIME,'Status':data[0][i].STATUS,'Sync_Status':data[0][i].SYNC_STATUS});
                       }
                          return self;
                        }

                    })
                }
                
                self.jobIDRptDP = new oj.ArrayDataProvider(self.jobIDRpt, {keyAttributes: 'Pair_Name'});
                
                
                self.jobPairColArray = [{headerText: 'Pair Name ',
                        field: 'Pair_Name'},
                    {headerText: 'Start Time',
                        field: 'Start_Time'},
                    {headerText: 'End Time',
                        field: 'End_Time'},
                    {headerText: 'Job Status',
                        field: 'Status'},
                    {headerText: 'Sync Status',
                        field: 'Sync_Status'}
                    ];
                

                self.jobIDItems = ko.observable({row: new keySet.KeySetImpl(), column: new keySet.KeySetImpl()});
                self.jobIDInfo = ko.observable('');
                self.jobIDSelectionMode = ko.observable({row: 'single', column: 'none'});

                self.jobIDSelectionMode.subscribe(function (newValue) {
                    // Reset selected Items on selection mode change.
                    self.jobIDItems({row: new keySet.KeySetImpl(), column: new keySet.KeySetImpl()});
                }.bind(this));

                self.jobIDChangedListener = function (event) {
                    var selectionText = '';

                    if (event.detail.value.row.isAddAll()) {
                        var iterator = event.detail.value.row.deletedValues();
                        iterator.forEach(function (key) {
                            selectionText = selectionText.length === 0 ? key : selectionText + ', ' + key;
                        });

                        if (iterator.size > 0) {
                            selectionText = ' except ' + selectionText;
                        }
                        selectionText = 'Row Selection:\nAll rows are selected' + selectionText;
                    } else {
                        if (event.detail.value.row.values().size > 0) {
                            event.detail.value.row.values().forEach(function (key) {
                                selectionText += (selectionText.length === 0 ? key : ', ' + key);
                            });
                            selectionText = selectionText;
                        }
                        if (event.detail.value.column.values().size > 0) {
                            event.detail.value.column.values().forEach(function (key) {
                                selectionText += (selectionText.length === 0 ? key : ', ' + key);
                            });
                            selectionText = 'Column Selection:\nColumn Keys: ' + selectionText;
                        }
                    }
                    self.jobIDInfo(selectionText);
                }.bind(this);




                self.pairJobRpt = ko.observableArray([]);
                self.pairHeadname = ko.observableArray([]);
                self.tabRowNum =  ko.observable();
                self.oosRowNum = ko.observable();
                
                self.compDataArray = ko.observableArray([]);
                
                self.viewRpt = function (data, event) {
                    self.pairJobRpt([]);
                    self.pairHeadname([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/jobrpt",
                        type: 'POST',
                        data: JSON.stringify({
                            jobName: self.selectedJobName(),
                            jobID  : self.selectedJobID(),
                            pairName : self.jobIDInfo()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {

                         for (var i = 0; i < data[1].length; i++) {   
                           self.pairJobRpt.push(data[1][i]);
                       }
                   
                     for (var i = 0; i < data[0].length; i++) {   
                         self.pairHeadname.push({ 'headerText': data[0][i] , 'field' :  data[0][i] })
                     }
              
             self.compDataArray.push(
                                {
                                      'id': 0 ,
                                  'series': 'In Sync',
                                    'group': 'Sync',
                                  'value': data[2] - data[3]
                              } ,
                               {
                                      'id': 1 ,
                                  'series': 'Out of Sync',
                                  'group': 'Sync',
                                  'value': data[3]
                              } 
                          
              );


                           document.querySelector('#viewRptDialog').open();
                                                                     return self;

                        }
                        
                        

                    })
                }
                

                
                 self.compDataArrayDP = new oj.ArrayDataProvider(self.compDataArray, {keyAttributes: 'id'});
                
                
                self.pairJobRptDP = new oj.ArrayDataProvider(self.pairJobRpt, {keyAttributes: 'Hash_Value'});
                

                        
                        
                self.viewRptOKClose = function (event) {
                    document.querySelector('#viewRptDialog').close();

                };

                self.cancel = function () {
                    oj.Router.rootInstance.go('compare');

                }

                self.connected = function () { 
                    if (sessionStorage.getItem("userName")==null) {
                        oj.Router.rootInstance.go('signin');
                    }
                    else
                    {
                      app.onAppSuccess();
                    }
        
                };

                /**
                 * Optional ViewModel method invoked after the View is disconnected from the DOM.
                 */
                self.disconnected = function () {
                    // Implement if needed
                };

                /**
                 * Optional ViewModel method invoked after transition to the new View is complete.
                 * That includes any possible animation between the old and the new View.
                 */
                self.transitionCompleted = function () {
                    // Implement if needed
                };
            }

            /*
             * Returns an instance of the ViewModel providing one instance of the ViewModel. If needed,
             * return a constructor for the ViewModel so that the ViewModel is constructed
             * each time the view is displayed.
             */
            return  CompJobViewModel;
        }
);
define(['ojs/ojcore', 'knockout', 'jquery','appController', 'ojs/ojarraydataprovider', 'ojs/ojasyncvalidator-regexp', 'ojs/ojconverterutils-i18n', 'ojs/ojconverter-datetime', 'ojs/ojconverter-number', 'ojs/ojknockout', 'ojs/ojtrain', 'ojs/ojradioset', 'ojs/ojbutton', 'ojs/ojlabelvalue', 'ojs/ojdatetimepicker', 'ojs/ojlabel', 'ojs/ojformlayout', 'ojs/ojinputtext', 'ojs/ojselectsingle', 'ojs/ojinputnumber', 'ojs/ojvalidationgroup', 'ojs/ojselectcombobox', 'ojs/ojdialog', 'ojs/ojswitch', 'ojs/ojcheckboxset', 'ojs/ojprogress-bar'],
        function (oj, ko, $, app, ArrayDataProvider, AsyncRegExpValidator, ConverterUtilsI18n, DateTimeConverter, NumberConverter) {

            class  AddReplicatViewModel {
                constructor(args){
                var self = this;

                self.ggVer = ko.observable();
                self.ggVersion = ko.observable();
                self.dbVer = ko.observable();
                self.repType = ko.observableArray([]);
                self.currentRepType = ko.observable('integrated');

                function getVersion() {
                    self.repType([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/ggversion",
                        type: 'GET',
                        dataType: 'json',
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            if ((data[1] == '191' || data[1] == '181' || data[1] == '123') && data[2] > '11')
                            {
                                self.repType.push(
                                        {label: 'Integrated Replicat', value: 'integrated'},
                                        {label: 'Classic Replicat', value: ''},
                                        {label: 'Coordinated Replicat', value: 'coordinated'},
                                        {label: 'Parallel Replicat', value: 'parallel'},
                                        {label: 'Parallel Integrated Replicat', value: 'parallelIR'}
                                );
                            } else if ((data[1] == '191' || data[1] == '181' || data[1] == '123') && data[2] == '11')
                            {
                                self.repType.push(
                                        {label: 'Integrated Replicat', value: 'integrated'},
                                        {label: 'Classic Replicat', value: ''},
                                        {label: 'Coordinated Replicat', value: 'coordinated'},
                                        {label: 'Parallel Replicat', value: 'parallel'}
                                );
                            } else if (data[1] <= '122' && data[2] == '11')
                            {
                                self.repType.push(
                                        {label: 'Integrated Replicat', value: 'integrated'},
                                        {label: 'Classic Replicat', value: ''},
                                        {label: 'Coordinated Replicat', value: 'coordinated'}
                                );
                            }
                            console.log(self)

                            return self;
                        }
                    })
                }


                self.args = args;
                // Create a child router with one default path
                self.router = self.args.parentRouter;

                self.optParam = ko.observable();

                self.currentParamList = ko.computed(function () {
                    if (self.optParam()) {
                        return self.optParam().toString().replace(/[,]/g, "\n");
                    } else
                    {
                        return '';

                    }
                });
                self.isFormReadonly = ko.observable(false);
                self.replicatDP = new ArrayDataProvider(self.repType, {keyAttributes: 'value'});
                self.selectedStepValue = ko.observable('stp1');
                self.selectedStepLabel = ko.observable('Replicat Type');
                self.selectedStepFormLabel = ko.observable('Replicat Type');

                self.stepArray =
                        ko.observableArray([
                            {label: 'Replicat Type', id: 'stp1'},
                            {label: 'Replicat Options', id: 'stp2'},
                            {label: 'Parameter File', id: 'stp3'}
                        ]);

                self.RepName = ko.observable();
                self.RepDesc = ko.observable();

                self.categorySelectionChanged = (event) => {
                    self.selectedSubcategory('');
                    let sub = getSubcategories(event.detail.value);
                    self.subcategories(sub);
                };

                self.ctvalue = ko.observable(ConverterUtilsI18n.IntlConverterUtils.dateToLocalIso(new Date()));

                self.secondConverter = new DateTimeConverter.IntlDateTimeConverter(
                        {
                            pattern: "yyyy-MM-dd HH:mm:ss"
                        });
                self.seqnovalue = ko.observable();
                self.rbavalue = ko.observable();

                self.decimalHalfDownConverter =
                        new NumberConverter.IntlNumberConverter({
                            style: 'decimal',
                            roundingMode: 'HALF_DOWN',
                            maximumFractionDigits: 0,
                            useGrouping: false
                        });


                self.RepTrail = ko.observable();
                self.RepTrailSize = ko.observable('500');

                self.modeVal = ko.observable("integrated");

                self.currentbeginmode = ko.observable('Begin Now');

                self.TrailName = ko.observable();
                self.trailSubDir = ko.observable();
                self.trailSubDirSlash = ko.observable('/');

                self.beginmode = ko.observableArray([
                    {value: 'Begin Now', label: 'Now'},
                    {value: 'Begin ', label: 'Custom Time'},
                    {value: 'LOC', label: 'Location'}
                ]);

                self.startOptionDP = new ArrayDataProvider(self.beginmode, {keyAttributes: 'value'});

                self.username1 = ko.observableArray([]);
                self.aliasname1 = ko.observableArray([]);
                self.domname1 = ko.observableArray([]);
                self.othdom = ko.observableArray([]);
                self.alias = ko.observable();
                self.user = ko.observable();
                self.valdom = ko.observable();
                self.uName = ko.observable();
                self.uPasswd = ko.observable();
                self.uRepPass = ko.observable();

                self.selectedDomCategory = ko.observable('OracleGoldenGate');
                self.selectedAliascategory = ko.observable();
                self.selectedUsercategory = ko.observable();
                self.aliascategories = ko.observableArray([]);
                self.unamecategories = ko.observable();

                function getDomains() {
                    self.username1([]);
                    self.othdom([]);
                    self.aliasname1([]);
                    self.domname1([]);
                    self.selectedAliascategory('');
                    self.selectedUsercategory('');
                    self.uRepPass()
                    self.uName('');
                    self.uPasswd('');
                    self.uRepPass('');
                    self.valdom('')
                    $.ajax({
                        url: "http://192.168.0.11:8080/ggcredstore",
                        type: 'GET',
                        dataType: 'json',
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {

                            for (var i = 0; i < data[1].length; i++) {
                                self.othdom.push({dom : data[1][i].value});
                                       }

                                       self.aliasname1(data[4]);


                                         for (var i = 0; i < data[2].length; i++) {
                                 self.domname1.push({label:data[2][i], value:data[2][i] }); 
                             }
    
                          for (var i = 0; i < data[0].length; i++) {
                                 self.username1.push({label:data[0][i].alias, value:data[0][i].alias,'children': [{label:data[0][i].uname,value:data[0][i].uname}] }); 
                             }

                            console.log(self)

                            return self;
                        }
                    })
                }


                self.DomProvider = new ArrayDataProvider(self.domname1, {keyAttributes: 'value'});
                self.OthDomProvider = new ArrayDataProvider(self.othdom, {keyAttributes: 'value'});

                self.chkTblList = ko.observableArray([]);
                self.currentChkptTbl = ko.observable();

self.queryChkTbl =  function (data, event) {
    self.chkTblList([]);
    self.currentChkptTbl('');
    $.ajax({
        url: "http://192.168.0.11:8080/infochkpttbl",
        type: 'POST',
        data: JSON.stringify({
            domain: self.selectedDomCategory(),
            alias: self.selectedAliascategory(),
        }),
        dataType: 'json',
        contrep: self,
        error: function (e) {
            console.log(e);
        },
        success: function (data) {

            for (var i = 0; i < data[0].length; i++) {
            self.chkTblList.push({'label':data[0][i],'value':data[0][i]});
            }
            return self;
        }

    })
}
self.chkpttblDP = new ArrayDataProvider(self.chkTblList, {keyAttributes: 'value'});

self.gotoGGAdmin = function (data, event) {
    self.router.go({path : 'ggadmin'})
}
                

                let getAliascategories = (category) => {
                    let found = self.aliasname1().find(c => c.value === category);
                    return found ? found.children : null;
                };
                let getUnamecategories = (category) => {
                    let found = self.username1().find(c => c.value === category);
                    return found ? found.children : null;
                };
                self.domSelectionChanged = (event) => {
                    self.selectedAliascategory('');
                    let children = getAliascategories(event.detail.value);
                    self.aliascategories(children);
                };


                self.aliasSelectionChanged = (event) => {
                    self.selectedUsercategory('');
                    let children = getUnamecategories(event.detail.value);
                    self.unamecategories(children);
                };

                self.value = ko.observable();

                self.groupValid = ko.observable();




                this.isRequired = ko.observable(true);
                this.checkboxValues = ko.observableArray(['required', 'helpSource', 'helpDef']);

                this.isRequired = ko.computed(function () {
                    return this.checkboxValues.indexOf('required') !== -1;
                }.bind(this));
                this.helpDef = ko.computed(function () {
                    return (this.checkboxValues.indexOf('helpDef') !== -1) ? this._HELP_DEF : null;
                }.bind(this));
                this.helpSource = ko.computed(function () {
                    return (this.checkboxValues.indexOf('helpSource') !== -1) ? this._HELP_SOURCE : null;
                }.bind(this));

                this.regExpValidator =
                        new AsyncRegExpValidator({
                            pattern: "[a-zA-Z ,.'-]{1,}",
                            hint: "1 or more letters",
                            messageDetail: "You must enter at least 1 letter"
                        });

                this.emailRegExpValidator =
                        new AsyncRegExpValidator({
                            pattern: ".+\@.+\..+",
                            hint: "email format",
                            messageDetail: "Invalid email format"
                        });

                self.previousStep = function () {
                    var train = document.getElementById('train');
                    var prev = train.getPreviousSelectableStep();
                    if (prev != null) {
                        self.selectedStepValue(prev);
                        self.selectedStepLabel(train.getStep(prev).label);
                        self.selectedStepFormLabel(train.getStep(prev).label);
                    }
                }.bind(this);

                self.nextStep = function (event) {
                    var train = document.getElementById('train');
                    var next = train.getNextSelectableStep();
                    var tracker = document.getElementById("tracker");
                    if (tracker == null) {
                        return;
                    }
                    if (tracker.valid === "valid") {
                        //The previous step will have a confirmation message type icon
                        self.selectedStepLabel.messageType = 'confirmation';
                        document.getElementById("train").updateStep(self.selectedStepValue, self.selectedStepValue);
                        //Now the clicked step could be selected
                        self.selectedStepValue(next);
                        self.selectedStepLabel(train.getStep(next).label);
                        self.selectedStepFormLabel(train.getStep(next).label);
                        return;
                    } else {
                        //The ojBeforeSelect can be cancelled by calling event.preventDefault().
                        event.preventDefault();
                        //The previous step will have an error message type icon
                        self.selectedStepLabel.messageType = 'error';
                        document.getElementById("train").updateStep(self.selectedStepLabel.id, self.selectedStepLabel);
                        // show messages on all the components
                        // that have messages hidden.
                        tracker.showMessages();
                        tracker.focusOn("@firstInvalidShown");
                        return;
                    }

                }.bind(this);
                //It is being called by the train to make sure the form is valid before moving on to the next step.



                self.AddReplicatMsg = ko.observable();

                //The method updates the label trep to show what step the user is on
                self.updateLabelText = function (event) {
                    if (self.selectedStepValue == 'stp2') {
                        self.selectedStepFormLabel('Replicat Options');
                        self.isFormReadonly(false);
                    } else if (self.selectedStepValue == "stp1") {
                        self.selectedStepFormLabel('Replicat Type');
                        self.isFormReadonly(false);
                    } else if (self.selectedStepValue == "stp3") {
                        self.selectedStepFormLabel('Parameter File');
                        self.isFormReadonly(true);
                    }
                }.bind(this);

                self.AddReplicatMsg = ko.observableArray([]);

                self.cancel = function () {
                   self.router.go({path: 'manage'});

                }

                self.currentRepParam = ko.observable();

                self.newparamList = ko.observable('');

                self.currentRepParamList = ko.computed({
                    read: function () {
                        var currentRepParam = 'REPLICAT ' + self.RepName() + '\n' + 'useridalias ' + self.selectedAliascategory() + ' domain ' + self.selectedDomCategory() + '\n' + 'REPORTCOUNT EVERY 5 MINUTES, RATE' + '\n'  + self.currentParamList();
                        return currentRepParam;
                    },
                    write: function (newVal) {
                        var currentRepParam = newVal;
                        return newVal;
                    }
                });


                self.confirm = function (data, event) {
                    document.querySelector('#CreateReplicatDialog').open();
                    $.ajax({
                        url: "http://192.168.0.11:8080/ggaddreplicat",
                        type: 'POST',
                        data: JSON.stringify({
                            repname: self.RepName(),
                            repdesc: self.RepDesc(),
                            domain: self.selectedDomCategory(),
                            alias: self.selectedAliascategory(),
                            repmode: self.currentRepType(),
                            beginmode: self.currentbeginmode(),
                            trailsubdir: self.trailSubDir(),
                            trailsubdirslash: self.trailSubDirSlash(),
                            trail: self.TrailName(),
                            chkpttbl : self.currentChkptTbl(),
                            currentParamList: self.newparamList()
                        }),
                        dataType: 'json',
                        contrep: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#CreateReplicatDialog').close();
                            document.querySelector('#AddReplicatDialog').open();
                            self.AddReplicatMsg(data[0]);
                            return self;
                        }

                    })
                }

                self.AddReplicatOKClose = function (event) {
                    document.querySelector('#AddReplicatDialog').close();
                    if (self.AddReplicatMsg().toString().includes('ERROR'))
                    {
                        self.router.go({ path : 'addreplicat' });
                    }
                    else 
                    {
                        self.router.go({ path : 'manage'});
                    }
                };



                self.connected = function () { 
                    if (sessionStorage.getItem("userName")==null) {
                       self.router.go({ path : 'signin'});
                    }
                    else
                    {
                    app.onAppSuccess();
                    getDomains();
                    getVersion();
                    self.selectedStepValue = ko.observable('stp1');
                    self.selectedStepLabel = ko.observable('Replicat Type');
                    self.selectedStepFormLabel = ko.observable('Replicat Type');
                    self.RepName('');
                    self.RepDesc('');
                    self.selectedDomCategory('');
                    self.selectedAliascategory('');
                    self.currentbeginmode('');
                    self.trailSubDir('');
                    self.TrailName('');
                    self.currentChkptTbl('');
                    }

                }

                /**
                 * Optional ViewModel method invoked after the View is disconnected from the DOM.
                 */
                self.disconnected = function () {

                    // Implement if needed
                };

                /**
                 * Optional ViewModel method invoked after transition to the new View is complete.
                 * That includes any possible animation between the old and the new View.
                 */
                self.transitionCompleted = function () {

                };

            }
            }
            return AddReplicatViewModel;
        }
);

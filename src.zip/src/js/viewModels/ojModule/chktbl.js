
define(['ojs/ojcore', 'knockout', 'jquery','appController','ojs/ojknockout', 'ojs/ojinputtext', 'ojs/ojlabel', 'ojs/ojformlayout','ojs/ojbutton', 'ojs/ojlabelvalue','ojs/ojdialog', 'ojs/ojprogress-bar'],
        function (oj, ko, $, app, keySet) {

            function chkTblViewModel() {
                var self = this;
                
                                self.username1 = ko.observableArray([]);
                self.aliasname1 = ko.observableArray([]);
                self.domname1 = ko.observableArray([]);
                self.othdom = ko.observableArray([]);
                self.alias = ko.observable();
                self.user = ko.observable();
                self.valdom = ko.observable();
                self.uName = ko.observable();
                self.uPasswd = ko.observable();
                self.uRepPass = ko.observable();

                self.selectedDomCategory = ko.observable();
                self.selectedAliascategory = ko.observable();
                self.selectedUsercategory = ko.observable();
                self.aliascategories = ko.observableArray([]);
                self.unamecategories = ko.observable();
                
                self.chkptTblName = ko.observable();

                self.HBTblFrequency = ko.observable(60);
                self.HBTblRetention = ko.observable(30);
                self.HBTblPurgeFrequency = ko.observable(1);
                self.selectedHBDomCategory = ko.observable();
                self.selectedHBAliascategory = ko.observable();
                
                
                function getDomains() {
                    self.username1([]);
                    self.othdom([]);
                    self.aliasname1([]);
                    self.domname1([]);
                    self.selectedAliascategory('');
                    self.selectedUsercategory('');
                    self.uRepPass()
                    self.uName('');
                    self.uPasswd('');
                    self.uRepPass('');
                    self.valdom('')
                    $.ajax({
                        url: "http://192.168.0.11:8080/ggcredstore",
                        type: 'GET',
                        dataType: 'json',
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {

                                             
                            for (var i = 0; i < data[1].length; i++) {
                                self.othdom.push({dom : data[1][i].value});
                                       }

                                       self.aliasname1(data[4]);


                                         for (var i = 0; i < data[2].length; i++) {
                                 self.domname1.push({label:data[2][i], value:data[2][i] }); 
                             }
    
                          for (var i = 0; i < data[0].length; i++) {
                                 self.username1.push({label:data[0][i].alias, value:data[0][i].alias,'children': [{label:data[0][i].uname,value:data[0][i].uname}] }); 
                             }

                            console.log(self)

                            return self;
                        }
                    })
                }
                
                                let getAliascategories = (category) => {
                    let found = self.aliasname1().find(c => c.value === category);
                    return found ? found.children : null;
                };
                let getUnamecategories = (category) => {
                    let found = self.username1().find(c => c.value === category);
                    return found ? found.children : null;
                };
                this.domSelectionChanged = (event) => {
                    self.selectedAliascategory('');
                    let children = getAliascategories(event.detail.value);
                    self.aliascategories(children);
                };


                self.aliasSelectionChanged = (event) => {
                    self.selectedUsercategory('');
                    let children = getUnamecategories(event.detail.value);
                    self.unamecategories(children);
                };

                self._HELP_DEF = 'SCHEMA.TABLENAME';

                self._HELP_FRE = 'Specifies how often the heartbeat seed table and heartbeat table are updated';
                self._HELP_RET = 'Specifies when heartbeat entries older than the retention time in the history table are purged';
                self._HELP_PURGE = 'Specifies how often the purge scheduler is run to delete table entries that are older than the retention time from the heartbeat history'
                self.isFormReadonly = ko.observable(false);
                this.isRequired = ko.observable(true);
                this.checkboxValues = ko.observableArray(['required', 'helpSource', 'helpDef']);

                this.isRequired = ko.computed(function () {
                    return this.checkboxValues.indexOf('required') !== -1;
                }.bind(this));
                this.helpDef = ko.computed(function () {
                    return (this.checkboxValues.indexOf('helpDef') !== -1) ? this._HELP_DEF : null;
                }.bind(this));
                this.helpDef1 = ko.computed(function () {
                    return (this.checkboxValues.indexOf('helpDef') !== -1) ? this._HELP_FRE : null;
                }.bind(this));
                this.helpDef2 = ko.computed(function () {
                    return (this.checkboxValues.indexOf('helpDef') !== -1) ? this._HELP_RET : null;
                }.bind(this));
                this.helpDef3 = ko.computed(function () {
                    return (this.checkboxValues.indexOf('helpDef') !== -1) ? this._HELP_PURGE : null;
                }.bind(this));
                this.helpSource = ko.computed(function () {
                    return (this.checkboxValues.indexOf('helpSource') !== -1) ? this._HELP_SOURCE : null;
                }.bind(this));
            

self.AddChkptTblMsg = ko.observable();

                self.addChkptTbl = function (data, event) {
                    self.AddChkptTblMsg('');
                    document.querySelector('#addChkTblDialog').open();
                    $.ajax({
                        url: "http://192.168.0.11:8080/ggaddchkpttbl",
                        type: 'POST',
                        data: JSON.stringify({
                            domain: self.selectedDomCategory(),
                            alias: self.selectedAliascategory(),
                            chkpttbl : self.chkptTblName()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#addChkTblDialog').close();
                            document.querySelector('#ChkptTblDialog').open();
                            self.AddChkptTblMsg(data[0]);
                            return self;
                        }

                    })
                }

                self.AddChkptTblMsgOKClose = function (event) {
                    document.querySelector('#ChkptTblDialog').close();
                };



                self.AddHBTblMsg = ko.observable();

                self.addHBTbl = function (data, event) {
                    self.AddHBTblMsg('');
                    document.querySelector('#addHBTblDialog').open();
                    $.ajax({
                        url: "http://192.168.0.11:8080/ggaddhbtbl",
                        type: 'POST',
                        data: JSON.stringify({
                            domain: self.selectedHBDomCategory(),
                            alias: self.selectedHBAliascategory(),
                            HBTblFrequency : self.HBTblFrequency(),
                            HBTblRetention : self.HBTblRetention(),
                            HBTblPurgeFrequency : self.HBTblPurgeFrequency()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#addHBTblDialog').close();
                            document.querySelector('#HBTblDialog').open();
                            self.AddHBTblMsg(data[0]);
                            return self;
                        }

                    })
                }

                self.AddHBTblMsgOKClose = function (event) {
                    document.querySelector('#HBTblDialog').close();
                };


                console.log(self);

                self.connected = function () { 
                    if (sessionStorage.getItem("userName")==null) {
                        oj.Router.rootInstance.go('signin');
                    }
                    else
                    {
                      app.onAppSuccess();
                      getDomains();
                    }
                };

                /**
                 * Optional ViewModel method invoked after the View is disconnected from the DOM.
                 */
                self.disconnected = function () {
                    // Implement if needed

                };

                /**
                 * Optional ViewModel method invoked after transition to the new View is complete.
                 * That includes any possible animation between the old and the new View.
                 */
                self.transitionCompleted = function () {
                    // Implement if needed

                };
            }

            /*
             * Returns a constructor for the ViewModel so that the ViewModel is constructed
             * each time the view is displayed.  Return an instance of the ViewModel if
             * only one instance of the ViewModel is needed.
             */
            return  chkTblViewModel;
        }
);

define([ 'ojs/ojoffcanvas' , 'knockout', 'ojs/ojmodule-element-utils', 'ojs/ojresponsiveutils', 'ojs/ojresponsiveknockoututils', 
         'ojs/ojcorerouter', 'ojs/ojmodulerouter-adapter', 'ojs/ojknockoutrouteradapter', 'ojs/ojurlparamadapter', 
         'ojs/ojarraydataprovider', 'ojs/ojknockouttemplateutils', 'ojs/ojmodule-element', 'ojs/ojknockout' ,'ojs/ojbutton'],
  function( OffcanvasUtils , ko , moduleUtils, ResponsiveUtils, ResponsiveKnockoutUtils, CoreRouter, ModuleRouterAdapter,
    KnockoutRouterAdapter, UrlParamAdapter, ArrayDataProvider, KnockoutTemplateUtils  ) {
     function ControllerViewModel() {
        var self = this;

      self.KnockoutTemplateUtils = KnockoutTemplateUtils;
        
        self.drawer = {
          displayMode: 'push',
          selector: '#drawer',
          content: '#main'
        };
  

        self.toggleDrawer = function () {
          return OffcanvasUtils.toggle(self.drawer);
        };
      
        self.username = ko.observable('');
        console.log(self)
        // Handle announcements sent when pages change, for Accessibility.
        self.manner = ko.observable('polite');
        self.message = ko.observable();
        document.getElementById('globalBody').addEventListener('announce', announcementHandler, false);

        function announcementHandler(event) {
          setTimeout(function() {
            self.message(event.detail.message);
            self.manner(event.detail.manner);
          }, 200);
        };

      // Media queries for repsonsive layouts
      var smQuery = ResponsiveUtils.getFrameworkQuery(ResponsiveUtils.FRAMEWORK_QUERY_KEY.SM_ONLY);
      self.smScreen = ResponsiveKnockoutUtils.createMediaQueryObservable(smQuery);

      self.count = ko.observable(3);
      // Navigation setup
      var navData = [
       { path:"" ,redirect : 'signin'},
       { path: 'signin', detail : {label: 'SignIn',iconClass: 'oj-navigationlist-item-icon demo-icon-font-24 demo-chart-icon-24' } },
       { path: 'processMon', detail : {label: 'processMon',iconClass: 'oj-navigationlist-item-icon demo-icon-font-24 demo-chart-icon-24'} },
       { path: 'dashboard', detail : {label: 'Dashboard',iconClass: 'fa fa-tachometer oj-navigationlist-item-icon'} },
       { path: 'dataflow', detail : {label: 'Dataflow',iconClass: 'oj-navigationlist-item-icon fa fa-random'} },
       { path: 'manage', detail : {label: 'Manage',iconClass: 'oj-navigationlist-item-icon fa fa-wrench'} },
       { path: 'monitor', detail : {label: 'Monitor',iconClass: 'oj-navigationlist-item-icon fa fa-area-chart',count : self.count} },
       { path: 'addextract', detail : {label: 'Add Extract',iconClass: 'oj-navigationlist-item-icon fa fa-plus-circle'} },
       { path: 'addreplicat', detail : {label: 'Add Replicat',iconClass: 'oj-navigationlist-item-icon fa fa-plus-circle'} },
       { path: 'initialload', detail : {label: 'Initial Load',iconClass: 'oj-navigationlist-item-icon fa fa-cloud-upload'} },
       { path: 'dumplog', detail : {label: 'Analyze Trails',iconClass: 'oj-navigationlist-item-icon demo-icon-font-24 demo-chart-icon-24'} }, 
       { path: 'ggadmin', detail : {label: 'Setup',iconClass: 'oj-navigationlist-item-icon fa fa-cogs'} }, 
       { path: 'tshoot', detail : {label: 'Troubleshoot',iconClass: 'oj-navigationlist-item-icon fa fa-search'} }, 
       { path: 'logfile', detail : {label: 'LogFile',iconClass: 'oj-navigationlist-item-icon fa fa-file-code-o'} }, 
       { path: 'compare', detail : {label: 'Compare',iconClass: 'oj-navigationlist-item-icon fa fa-balance-scale'} },
      ];




      // Router setup
      let router = new CoreRouter(navData, {
        urlAdapter: new UrlParamAdapter()
      });
      router.sync();



      self.moduleAdapter = new ModuleRouterAdapter(router);

      self.selection = new KnockoutRouterAdapter(router);

      self.navDataProvider = new ArrayDataProvider(navData.slice(3), {keyAttributes: "path"});

      // Header
      // Application Name used in Branding Area
      self.appName = ko.observable("Goldengate OnePlace Client Console");
      // User Info used in Global Navigation area


      // Footer
      function footerLink(name, id, linkTarget) {
        this.name = name;
        this.linkId = id;
        this.linkTarget = linkTarget;
      }


      self.footerLinks = ko.observableArray([
        new footerLink('About EchoApps360', 'aboutEchoApps360', 'http://echoapps360.com/about'),
        new footerLink('Contact Us', 'contactUs', 'http://echoapps360.com/contact-us'),
        new footerLink('Legal Notices', 'legalNotices', 'http://echoapps360.com/contact-us'),
        new footerLink('Terms Of Use', 'termsOfUse', 'http://echoapps360.com/contact-us'),
        new footerLink('Your Privacy Rights', 'yourPrivacyRights', 'http://echoapps360.com/contact-us')
      ]);


     self.SignIn = ko.observable('N');

     self.goToSignIn = function() {
      router.go({path : 'signin'});
      self.SignIn('N');
    };
  
    ControllerViewModel.prototype.signIn = function() {
      if (!self.localFlow) {
        self.goToSignIn();
        return;
      }
    }


    ControllerViewModel.prototype.onAppSuccess = function() {
      self.username(sessionStorage.getItem("userName"));
      self.SignIn('Y');
    };

    ControllerViewModel.prototype.onLoginSuccess = function() {
      router.go({path : 'dashboard'});
      self.SignIn('Y');
    };

    self.selectedMenuItem = ko.observable('');
  
    self.menuItemAction = function (event,vm) {
      self.selectedMenuItem(event.target.value);
        //User menu Options
      if (self.selectedMenuItem() == 'out')
      {
        self.username('');
        sessionStorage.clear();
      event.preventDefault();
      self.goToSignIn();
      }
    }
  }

     return new ControllerViewModel();
  }
);

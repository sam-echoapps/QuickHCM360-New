define(['ojs/ojcore', 'knockout','ojs/ojmodule-element-utils', 'ojs/ojmodule-element', 'ojs/ojknockout', 'ojs/ojbutton'],
        function (oj, ko, moduleUtils )  {
            function LogFileViewModel() {
                var self = this;


function resolveVVM(name, moduleConfig) {
        var viewPath = name !== 'oj:blank' ? 'views/ojLogView/' + name + '.html' : null;
        var modelPath = name !== 'oj:blank' ? 'viewModels/ojLogView/' + name : null;
        var masterPromise = Promise.all([
          moduleUtils.createView({'viewPath':viewPath}),
          moduleUtils.createViewModel({'viewModelPath':modelPath})
        ]);
        masterPromise.then(
          function(values){
            moduleConfig({'view':values[0],'viewModel':values[1]});
          },
          function(reason){}
        );
      };
      
      var self = this;
      self.currentModule = ko.observable("alllog");
      self.moduleConfig = ko.observable({'view':[],'viewModel':null});
      
      resolveVVM(self.currentModule(), self.moduleConfig);
      self.currentModule.subscribe(function(name) {
        resolveVVM(name, self.moduleConfig);
      });
 
                self.valueChangedHandler = function (event) {
                    self.eventData(event.detail);
                }

     self.connected = function () { 
      if (sessionStorage.getItem("userName")==null) {
        oj.Router.rootInstance.go('signin');
    }
    else
    {
      oj.FocusUtils.focusFirstTabStop(document.getElementById('sv1')); 
      document.getElementById('sv1').refresh();
    }
          };
            }
            return  LogFileViewModel;
        });




define(['ojs/ojcore', 'knockout', 'jquery','appController' ,'ojs/ojknockout-keyset', 'ojs/ojknockout', 'ojs/ojlistview', 'ojs/ojlistitemlayout', 'ojs/ojinputtext', 'ojs/ojlabel', 'ojs/ojformlayout','ojs/ojswitch'],
        function (oj, ko, $, app, keySet) {

            function pfileViewModel() {
                var self = this;
                self.paramFileList = ko.observableArray([]);



                function paramfile() {
                    self.paramFileList([]);
                    $.ajax({
                        url: "http://192.168.0.11:8080/listprm",
                        type: 'GET',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {

                            for (var i = 0; i < data[0].length; i++) {

                                self.paramFileList.push({'Paramfile': data[0][i]});
                            }

                            console.log(self);
                            return self;
                        }

                    })

                }

                self.paramfileDP = new oj.ArrayDataProvider(self.paramFileList, {keyAttributes: 'Paramfile'});

                self.selectedItems = new keySet.ObservableKeySet(); // observable bound to selection option to monitor current selections
                self.selectedSelectionRequired = ko.observable(true);
                self.firstSelectedItem = ko.observable();
                self.selectedPrmFile = ko.observableArray([]);

                self.getDisplayValue = function (set) {
                    var arr = [];
                    set.values().forEach(function (key) {
                        arr.push(key);
                    });
                    return JSON.stringify(arr);
                };




                self.prmFileContent = ko.observable();



                self.viewPrm = function (data, event) {
                    self.prmFileContent('');
                    $.ajax({
                        url: "http://192.168.0.11:8080/viewprm",
                        type: 'POST',
                        data: JSON.stringify({
                            prmFile: self.getDisplayValue(self.selectedItems())
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            self.prmFileContent(data[0]);
                            return self;
                        }

                    })
                }

                self.textstateValue = ko.observable(true);
                self.edBtnstateValue = ko.observable();
                self.saveBtnStateValue = ko.observable(true);

                self.selectedButton = ko.observable();

                self.cancel = function () {
                    var disabledState = self.textstateValue();
                    self.textstateValue(true);
                    self.edBtnstateValue(false);
                    self.saveBtnStateValue(true);
                };


                self.editListener = function (event)
                {
                    // toggle the componentDisable knockout binding
                    var disabledState = self.textstateValue();
                    self.textstateValue(!disabledState);
                    self.edBtnstateValue(disabledState);
                    self.saveBtnStateValue(!disabledState);

                }.bind(this);


                self.savePrmMsg = ko.observable();

                self.saveListener = function (data, event) {
                    $.ajax({
                        url: "http://192.168.0.11:8080/saveprm",
                        type: 'POST',
                        data: JSON.stringify({
                            prmFile: self.getDisplayValue(self.selectedItems()),
                            prmContent : self.prmFileContent()
                        }),
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            self.savePrmMsg(data[0]);
                            document.querySelector('#savePrmDialog').open();
                            return self;
                        }

                    })
                }

                self.savePrmOKClose = function (event) {
                    document.querySelector('#savePrmDialog').close();
                           var disabledState = self.textstateValue();
                    self.textstateValue(!disabledState);
                    self.edBtnstateValue(disabledState);
                    self.saveBtnStateValue(!disabledState);
                };

                console.log(self);
                self.connected = function () { 
                    app.onAppSuccess();
                    // Implement if needed
                    self.paramFileList([]);
                    paramfile();

                };

                /**
                 * Optional ViewModel method invoked after the View is disconnected from the DOM.
                 */
                self.disconnected = function () {
                    // Implement if needed

                };

                /**
                 * Optional ViewModel method invoked after transition to the new View is complete.
                 * That includes any possible animation between the old and the new View.
                 */
                self.transitionCompleted = function () {
                    // Implement if needed

                };
            }

            /*
             * Returns a constructor for the ViewModel so that the ViewModel is constructed
             * each time the view is displayed.  Return an instance of the ViewModel if
             * only one instance of the ViewModel is needed.
             */
            return  pfileViewModel;
        }
);

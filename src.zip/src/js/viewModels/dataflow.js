
define(['ojs/ojcore', 'knockout', 'jquery','appController','ojs/ojconverter-number', 'ojDiagram/viewModels/ggLayout','ojs/ojknockout-keyset','ojs/ojattributegrouphandler','ojs/ojarraydataprovider', 'ojs/ojarraytreedataprovider','ojs/ojknockout', 'ojs/ojdiagram','ojs/ojdialog','ojs/ojprogress-bar'],
        function (oj, ko, $, app,NumberConverter, layout, keySet ,attributeGroupHandler,ArrayDataProvider,ArrayTreeDataProvider) {

            function DataFlowViewModel() {
                var self = this;
                self.ExtName = ko.observable();
               
                self.RepName = ko.observable();
               
                self.ExtData1 = ko.observableArray(['']);
                self.RepData1 = ko.observableArray(['']);
                
                self.styleExt = ko.observable();
                self.styleRep = ko.observable();
                self.ExtATCSN = ko.observable();
                                self.ExtAFTERCSN = ko.observable();
                
                                self.RepATCSN = ko.observable();
                                self.RepAFTERCSN = ko.observable();
                                self.decimalHalfDownConverter =
                                new NumberConverter.IntlNumberConverter({
                                    style: 'decimal',
                                    roundingMode: 'HALF_DOWN',
                                    maximumFractionDigits: 0,
                                    useGrouping: false
                                });
        

                self.NodeData = ko.observableArray([]);
                self.LinkData = ko.observableArray([]);

               function getReplionFlow() {
                   
                    self.NodeData([]);
                    self.LinkData([]);
                    $.ajax({
                         url: 'http://192.168.0.11:8080/gginfodiag',
                        type: 'GET',
                        dataType: 'json',

                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {

                                self.NodeData.push({'id' : data[0].uid ,'nodes' : data[0].nodeext},{'id' : data[0].pid ,'nodes' : data[0].nodepmp},{'id' : data[0].id ,'nodes' : data[0].noderep});

                            for (var i = 0; i < data[1].length; i++) {
                                self.LinkData.push({'start' : data[1][i].start,'category' :data[1][i].category ,'end' :data[1][i].end,'id' : i});
                            }
                            console.log(self);

                            return self;

                        }
                    })

                };

                function refresh() {     
                  self.ExtData1([]);
                                   self.RepData1([]);
               $.ajax({
                   url: "http://192.168.0.11:8080/gginfoall",
                   type: 'GET',
                   dataType: 'json',
                   context: self,
                   error: function (e) {
                       console.log(e);
                   },
                   success: function (data) {
  
                       for (var i = 0; i < data[1].length; i++) {

                           if (data[1][i].ExtStat == 'ABENDED') {

                               self.styleExt = {"background-color": "IndianRed"};
                               self.ExtData1.push({ExtName: data[1][i].ExtName, ExtStat: data[1][i].ExtStat, ExtLag: data[1][i].ExtLag, ExtLagChk: data[1][i].ExtLagChk ,collapsedSizeClass: 'oj-masonrylayout-tile-1x1',expandedSizeClass: 'oj-masonrylayout-tile-1x2' ,expanded: ko.observable(false) });

                           } else if (data[1][i].ExtStat == 'STOPPED') {

                               self.styleExt = {"background-color": "Chocolate"};
                               self.ExtData1.push({ExtName: data[1][i].ExtName, ExtStat: data[1][i].ExtStat, ExtLag: data[1][i].ExtLag, ExtLagChk: data[1][i].ExtLagChk,collapsedSizeClass: 'oj-masonrylayout-tile-1x1',expandedSizeClass: 'oj-masonrylayout-tile-1x2',expanded: ko.observable(false) });

                           } else if (data[1][i].ExtStat == 'RUNNING') {

                               self.styleExt = {"background-color": "ForestGreen"};
                               self.ExtData1.push({ExtName: data[1][i].ExtName, ExtStat: data[1][i].ExtStat, ExtLag: data[1][i].ExtLag, ExtLagChk: data[1][i].ExtLagChk,collapsedSizeClass: 'oj-masonrylayout-tile-1x1',expandedSizeClass: 'oj-masonrylayout-tile-1x2',expanded: ko.observable(false) });
                           }

                       }


                       for (var i = 0; i < data[2].length; i++) {

                           if (data[2][i].RepStat == 'ABENDED') {
                               self.styleRep = {"background-color": "IndianRed"};
                               self.RepData1.push({RepName : data[2][i].RepName ,collapsedSizeClass: 'oj-masonrylayout-tile-1x1',expandedSizeClass: 'oj-masonrylayout-tile-1x2' ,expanded: ko.observable(false)});
                           } else if (data[2][i].RepStat == 'STOPPED') {

                               self.styleRep = {"background-color": "Chocolate"};
                               self.RepData1.push({RepName : data[2][i].RepName ,collapsedSizeClass: 'oj-masonrylayout-tile-1x1',expandedSizeClass: 'oj-masonrylayout-tile-1x2' ,expanded: ko.observable(false)});
                           } else if (data[2][i].RepStat == 'RUNNING') {

                               self.styleRep = {"background-color": "ForestGreen"};
                               self.RepData1.push({RepName : data[2][i].RepName ,collapsedSizeClass: 'oj-masonrylayout-tile-1x1',expandedSizeClass: 'oj-masonrylayout-tile-1x2' ,expanded: ko.observable(false)});
                           }
                   }
                    return self;
               }
               })

           }



                self.nodeDataProvider = new ArrayTreeDataProvider(self.NodeData, {keyAttributes: 'id', childrenAttribute: "nodes"});
                self.linkDataProvider = new ArrayDataProvider(self.LinkData,{keyAttributes: 'id'});
                var color = (new attributeGroupHandler.ColorAttributeGroupHandler()).getValue(0);
                self.expandedNodes = new keySet.ObservableKeySet().add(['Extracts','Replicats']);
                self.layoutFunc = layout.containerLayout;
        
        this.linkRendererFunc = function (context) {
          var rootElement = context.rootElement;
          
          var width = context.state.hovered || context.state.selected ? 
            2 : 1;
          if (!rootElement) {
            var linkid = context.type === 'promotedLink' ? 
              context.id.name + context.id.startId + context.id.endId : context.id;
            var rootElement = createGroup('linkSvg' + linkid);
            addPath(rootElement, 10, context.state.selected, 'underlay', context.points);
            addPath(rootElement, width, context.state.selected, context.type);
          } else {
            var visiblePath = rootElement.children[1];
            visiblePath.setAttribute("stroke-width", width);
            visiblePath.classList.toggle("demo-diagram-selected-link", context.state.selected);
          }
          return {"insert": rootElement};
        };
  
        this.nodeRendererFunc = function (context) {
          var color = context.state.selected ? 'red' : '#87ceeb';   //header color 
          var stroke = context.state.selected || context.state.hovered ? 3 : 1;
          var rootElement = context.rootElement;
          if (!rootElement) {
            // initial rendering - create an svg element with a node content in it
            var nodeId = context.data['id'];
            if (context.state.expanded) {
              //render expanded node
              var childContent = context.content;
              // add 20 px for the each side padding and 
              // additional 20 px on top for the header
              var w = childContent.w + 80,
                  h = childContent.h + 100;
              rootElement = createSVG('nodeSvg' + nodeId, w, h);
              var group = addGroup(rootElement, 'topGroup' + nodeId);
              w-=2, h-=2; //reduce width and height for inner elements
              addRect(group, 'rect' + nodeId, 1, 1, w, h, "#FFFFFF");   
              addRect(group, 'rectHdr' + nodeId, 1, 1, w, 25, color); //header size 
              addChildContent(group, childContent.element);
            }
            else {
              //render collapsed or leaf node
              rootElement = createSVG('nodeSvg' + nodeId, 1000,1000);  //size of the main container
              var group = addGroup(rootElement, 'topGroup' + nodeId);
              addRect(group, 'rectInner' + nodeId, 15 , 5, 150, 35, "#daf5f4"); //position of the child containers inside main
            }
          }
          else {// modification case - apply custom treatment to the node
              var group = rootElement.childNodes[0];
              var outerRect = group.childNodes[0];
              outerRect.setAttributeNS(null, "stroke", color);
              outerRect.setAttributeNS(null, "stroke-width", stroke);
              if (context.state.expanded) {
                //change header color for the container node
                var hdrRect = group.childNodes[1];
                hdrRect.setAttributeNS(null, "stroke", color);
                hdrRect.setAttributeNS(null, "stroke", color);
              }
          }
          return {"insert":rootElement};
        };
        // SVG helper functions for node rendering
        function createSVG (id, width, height) {
          var svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
          svg.setAttributeNS(null, 'width', width);
          svg.setAttributeNS(null, 'height', height);
          svg.setAttributeNS(null, 'viewBox', "0 0 " +  width + " " + height);
          return svg;
        };
        function addGroup (parent, id) {
          var group = document.createElementNS('http://www.w3.org/2000/svg','g');
          group.setAttributeNS(null, 'id', id);
          parent.appendChild(group);
          return group;
        };
        function addRect (parent, id, x, y, w, h, fill) {
          var svgRect = document.createElementNS('http://www.w3.org/2000/svg','rect');
          svgRect.setAttributeNS(null, "id", id);
          svgRect.setAttributeNS(null, "x", x);
          svgRect.setAttributeNS(null, "y", y);
          svgRect.setAttributeNS(null, "width", w);
          svgRect.setAttributeNS(null, "height", h);        
          svgRect.setAttributeNS(null, "fill", fill);
          svgRect.setAttributeNS(null, "stroke", "#87ceeb");
          svgRect.setAttributeNS(null, "stroke-width", 1);
          parent.appendChild(svgRect);
          return svgRect;
        };
        function addChildContent (parent, elem) {
          parent.appendChild(elem);
          elem.setAttributeNS(null, "transform", "translate(20 40)");
        };
        
        // SVG helper functions for link rendering
        function createGroup(id) {
          var group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
          group.setAttribute('id', id);
          return group;
        };
        function addPath(parent, width, selected, type, points) {
          var svgPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
          var linkSvgClasses = type === 'underlay' ? 
            'demo-diagram-link-underlay' : "demo-diagram-link oj-diagram-link-path demo-diagram-promoted-link";
          if (type === 'underlay') {
            svgPath.setAttribute("d", points.join(' '));
          }
          else {
            if (type === 'promotedLink')
              linkSvgClasses += ' demo-diagram-promoted-link';
            if (selected)
              linkSvgClasses += ' demo-diagram-selected-link';
          }
          svgPath.setAttribute("stroke-width", width);
          svgPath.setAttribute("class", linkSvgClasses);
          parent.appendChild(svgPath);
        };

      function getStyleUrl(styleId) {
        return 'url(' + document.URL + '#' + styleId + ')';
      }
      self.selectedNodesValue = ko.observable();
      self.selectionValue = ko.observable("single");

      self.ExtRpt = ko.observableArray([]);
      self.selectedMenuItem = ko.observable('');
  
      self.selectionText = ko.pureComputed(function() {
        var items = self.selectedNodesValue().join(", ");
        return items;
      });

      self.username1 = ko.observableArray([]);
      self.aliasname1 = ko.observableArray([]);
      self.domname1 = ko.observableArray([]);
      self.othdom = ko.observableArray([]);
      self.alias = ko.observable();
      self.user = ko.observable();
      self.valdom = ko.observable();
      self.uName = ko.observable();
      self.uPasswd = ko.observable();
      self.uRepPass = ko.observable();
      self.selectedAliascategory = ko.observable();
      self.selectedUsercategory = ko.observable();
      self.aliascategories = ko.observableArray([]);
      self.unamecategories = ko.observable();
                      self.selectedDomCategory = ko.observable();

      function getDomains() {
          self.username1([]);
          self.othdom([]);
          self.aliasname1([]);
          self.domname1([]);
          self.selectedAliascategory('');
          self.selectedUsercategory('');
          self.uRepPass()
          self.uName('');
          self.uPasswd('');
          self.uRepPass('');
          self.valdom('')
          $.ajax({
              url: "http://192.168.0.11:8080/ggcredstore",
              type: 'GET',
              dataType: 'json',
              error: function (e) {
                  console.log(e);
              },
              success: function (data) {

                  for (var i = 0; i < data[3].length; i++) {
                      self.aliasname1.push({label: data[3][i].dom, value: data[3][i].dom, 'children': [{label: data[3][i].alias, value: data[3][i].alias}]});
                  }
                  for (var i = 0; i < data[1].length; i++) {
                      self.othdom.push({dom: data[1][i].value});


                  }

                  for (var i = 0; i < data[2].length; i++) {
                      self.domname1.push({label: data[2][i], value: data[2][i]});
                  }


                  for (var i = 0; i < data[0].length; i++) {
                      self.username1.push({label: data[0][i].alias, value: data[0][i].alias, 'children': [{label: data[0][i].uname, value: data[0][i].uname}]});
                  }


                  console.log(self)

                  return self;
              }
          })
      }



      let getAliascategories = (category) => {
        let found = self.aliasname1().find(c => c.value === category);
        return found ? found.children : null;
    };
    let getUnamecategories = (category) => {
        let found = self.username1().find(c => c.value === category);
        return found ? found.children : null;
    };
    this.domSelectionChanged = (event) => {
        self.selectedAliascategory('');
        let children = getAliascategories(event.detail.value);
        self.aliascategories(children);
    };


    self.aliasSelectionChanged = (event) => {
        self.selectedUsercategory('');
        let children = getUnamecategories(event.detail.value);
        self.unamecategories(children);
    };

      this.isRequired = ko.observable(true);
      this.checkboxValues = ko.observableArray(['required', 'helpSource', 'helpDef']);

      this.isRequired = ko.computed(function () {
          return this.checkboxValues.indexOf('required') !== -1;
      }.bind(this));
      this.helpDef = ko.computed(function () {
          return (this.checkboxValues.indexOf('helpDef') !== -1) ? this._HELP_DEF : null;
      }.bind(this));
      this.helpSource = ko.computed(function () {
          return (this.checkboxValues.indexOf('helpSource') !== -1) ? this._HELP_SOURCE : null;
      }.bind(this));

      self.menuItemAction = function (event) {
        self.selectedMenuItem(event.target.value);
        if (self.selectedMenuItem() == 'extrpt')
        {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "/viewextrpt",
                        data: JSON.stringify({
                            extname: self.selectionText()
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                                    self.ExtRpt(data[0]); 
                            console.log(self);
                            return self;

                        }

                    })
                    }
        else if (self.selectedMenuItem() == 'extchk')
        {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "/viewextchk",
                        data: JSON.stringify({
                            extname: self.selectionText()
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();

                                    self.ExtRpt(data[0]); 
                                console.log(self);
                            return self;

                        }

                    })
                    }
                    
                            else if (self.selectedMenuItem() == 'extstats')
        {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "/extstats",
                        data: JSON.stringify({
                            extname: self.ExtName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();

                                    self.ExtRpt(data[0]); 

                            return self;

                        }

                    })
                    }
                            else if (self.selectedMenuItem() == 'extstartdef')
                {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "/extstart",
                        data: JSON.stringify({
                            extname: self.ExtName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                                 self.ExtRpt(data[0]); 
                        return self;

                        }

                    })
                    }              
                            else if (self.selectedMenuItem() == 'extatcsn')
                {   self.ExtATCSN(0);
                     document.querySelector('#ExtractATCSNDialog').open();
              
                 }
                     else if (self.selectedMenuItem() == 'extaftercsn')
                {   self.ExtAFTERCSN(0);
                     document.querySelector('#ExtractAFTERCSNDialog').open();
              
                 }
                 
                                     else if (self.selectedMenuItem() == 'extstop')
                {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "/extstop",
                        data: JSON.stringify({
                            extname: self.ExtName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                                 self.ExtRpt(data[0]); 
                        return self;

                        }

                    })
                    }              
                                                     else if (self.selectedMenuItem() == 'extforcestop')
                {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "/extforcestop",
                        data: JSON.stringify({
                            extname: self.ExtName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                                 self.ExtRpt(data[0]); 
                        return self;

                        }

                    })
                    }    
                    
                                           else if (self.selectedMenuItem() == 'extkill')
                {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "/extkill",
                        data: JSON.stringify({
                            extname: self.ExtName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                                 self.ExtRpt(data[0]); 
                        return self;

                        }

                    })
                    }                           
                                           else if (self.selectedMenuItem() == 'upgie')
                {getDomains();
                 document.querySelector('#ExtLoginDialog').open();
                        }
                       else if (self.selectedMenuItem() == 'delext')
                {getDomains();
                 document.querySelector('#ExtLoginDialog').open();
                        }
      }
   
   
   self.ViewExtractRptOKClose = function (event) {
                    refresh();
                    document.querySelector('#ViewExtractRptDialog').close();
                     document.querySelector('#ExtLoginDialog').close();
                };

     
                      self.ExtStartATCSN = function(data,event) {
                           {
                    self.ExtRpt([]);
                    $.ajax({
                        url: "/extstartatcsn",
                        data: JSON.stringify({
                            extname: self.ExtName,
                            extatcsn: self.ExtATCSN()
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                            self.ExtRpt(data[0]); 
                            document.querySelector('#ExtractATCSNDialog').close();
                        return self;

                        }

                    })
                    }              
                     }                
                  
                  
                  
                                 self.ExtStartAFTERCSN = function(data,event) {
                           self.ExtRpt([]);
                    $.ajax({
                        url: "/extstartaftercsn",
                        data: JSON.stringify({
                            extname: self.ExtName,
                            extaftercsn: self.ExtAFTERCSN()
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                                 self.ExtRpt(data[0]); 
                                 document.querySelector('#ExtractAFTERCSNDialog').close();
                        return self;

                        }

                    })
                    }              
                     
             
                              self.ExtUpgTOIE = function(data,event) {
                self.ExtRpt([]);
                document.querySelector('#UpgExtractDialog').open();
                
                    $.ajax({
                        url: "/extupgie",
                        data: JSON.stringify({
                            extname: self.ExtName,
                            domain: self.selectedDomCategory(),
                            alias: self.selectedAliascategory()
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#UpgExtractDialog').close();
                            document.querySelector('#ViewExtractRptDialog').open();
                                 self.ExtRpt(data[0]); 
                                 
                        return self;
     }

                    })
                    }      
                    
                    
                    self.DelExt = function(data,event) {
                        self.ExtRpt([]);
                    $.ajax({
                        url: "/delext",
                        data: JSON.stringify({
                            extname: self.ExtName,
                            domain: self.selectedDomCategory(),
                            alias: self.selectedAliascategory()
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                                 self.ExtRpt(data[0]); 
                        return self;
                        }

                    })
                    }
                    
                    
                    
                    self.RepRpt = ko.observableArray([]);
                     self.selectedRepMenuItem = ko.observable('');
  
      self.menuRepItemAction = function (event) {
        self.selectedRepMenuItem(event.target.value);
        if (self.selectedRepMenuItem() == 'reprpt')
        {
                    self.RepRpt([]);
                    $.ajax({
                        url: "/viewextrpt",
                        data: JSON.stringify({
                            extname: self.RepName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewReplicatRptDialog').open();
                                    self.RepRpt(data[0]); 
                            console.log(self);
                            return self;

                        }

                    })
                    }
                                else if (self.selectedRepMenuItem() == 'delrep')
                {getDomains();
                 document.querySelector('#RepLoginDialog').open();
                        }
                                        else if (self.selectedRepMenuItem() == 'repstartdef')
                {
                                     self.RepRpt([]);
                    $.ajax({
                        url: "/extstart",
                        data: JSON.stringify({
                            extname: self.RepName
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewExtractRptDialog').open();
                                 self.RepRpt(data[0]); 
                        return self;

                        }

                    })
                    }     
                   }
          
                
                                 self.DelRep = function(data,event) {
                        self.RepRpt([]);
                    $.ajax({
                        url: "/delext",
                        data: JSON.stringify({
                            extname: self.RepName,
                            domain: self.selectedDomCategory(),
                            alias: self.selectedAliascategory()
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewReplicatRptDialog').open();
                                 self.RepRpt(data[0]); 
                        return self;
                        }

                    })
                    }
                    
       self.ViewReplicatRptOKClose = function (event) {
                    refresh();
                    document.querySelector('#ViewReplicatRptDialog').close();
                     document.querySelector('#RepLoginDialog').close();
                };            
                
                console.log(self);
                
                                      self.RepStartATCSN = function(data,event) {
                           {
                    self.RepRpt([]);
                    $.ajax({
                        url: "/extstartatcsn",
                        data: JSON.stringify({
                            extname: self.ExtName,
                            extatcsn: self.ExtATCSN()
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewReplicatRptDialog').open();
                            self.ExtRpt(data[0]); 
                            document.querySelector('#ReplicatATCSNDialog').close();
                        return self;

                        }

                    })
                    }              
                     }                
                  
                  
                  
                                 self.RepStartAFTERCSN = function(data,event) {
                           self.RepRpt([]);
                    $.ajax({
                        url: "//extstartaftercsn",
                        data: JSON.stringify({
                            extname: self.RepName,
                            extaftercsn: self.RepAFTERCSN()
                        }),
                        type: 'POST',
                        dataType: 'json',
                        context: self,
                        error: function (e) {
                            console.log(e);
                        },
                        success: function (data) {
                            document.querySelector('#ViewReplicatRptDialog').open();
                                 self.ExtRpt(data[0]); 
                                 document.querySelector('#ReplicatAFTERCSNDialog').close();
                        return self;

                        }

                    })
                    }        



            // Below are a set of the ViewModel methods invoked by the oj-module component.
            // Please reference the oj-module jsDoc for additional information.

            /**
             * Optional ViewModel method invoked after the View is inserted into the
             * document DOM.  The application can put logic that requires the DOM being
             * attached here. 
             * This method might be called multiple times - after the View is created 
             * and inserted into the DOM and after the View is reconnected 
             * after being disconnected.
             */
            self.connected = function () { 
                if (sessionStorage.getItem("userName")==null) {
                    oj.Router.rootInstance.go('signin');
                }
                else
                {
                app.onAppSuccess();
                getReplionFlow();
                }
            };

            /**
             * Optional ViewModel method invoked after the View is disconnected from the DOM.
             */
            self.disconnected = function () {


                // Implement if needed
            };

            /**
             * Optional ViewModel method invoked after transition to the new View is complete.
             * That includes any possible animation between the old and the new View.
             */
            self.transitionCompleted = function () {

                // Implement if needed
            };
            }

    /*
     * Returns a constructor for the ViewModel so that the ViewModel is constructed
     * each time the view is displayed.  Return an instance of the ViewModel if
     * only one instance of the ViewModel is needed.
     */
    return new DataFlowViewModel();
}
);

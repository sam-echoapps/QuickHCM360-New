
define(['ojs/ojcore', 'knockout', 'jquery', 'appController', 'ojs/ojarraydataprovider', 'ojs/ojbutton', 'ojs/ojtable', 'ojs/ojdialog', 'ojs/ojinputtext', 'ojs/ojselectsingle'],
    function (oj, ko, $, app, ArrayDataProvider) {

        function addsuppViewModel() {
            var self = this;
            self.dbSuppInfo = ko.observableArray([]);

            self.DBDet = ko.observableArray([]);
            self.currentDB = ko.observable();
            self.schemaNameList = ko.observableArray([]);


            function getDB() {
                self.DBDet([]);
                $.ajax({
                    url: "http://192.168.0.11:8080/dbdet",
                    type: 'GET',
                    dataType: 'json',
                    context: self,
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {
                        for (var i = 0; i < data[0].length; i++) {
                            self.DBDet.push({value:data[0][i],label:data[0][i]});
                    }
                    return self;
                }
                })
            }
            self.dberr = ko.observable();
            self.CancelBehaviorOpt = ko.observable('icon');
            
            self.DBParam = ko.observable();
            self.getSuppLog = function(event,data)  {
                self.dbSuppInfo([]);
                $.ajax({
                    url: "http://192.168.0.11:8080/supplog",
                    type: 'POST',
                    dataType: 'json',
                    data: JSON.stringify({
                        dbname : self.currentDB()
                    }),
                    context: self,
                    error: function (e) {
                            console.log(e)   
                    },
                    success: function (data) {
                       self.dbSuppInfo.push({ 'LogMode': data[0][0].LOG_MODE, 'SuppLog': data[0][0].SUPPLEMENTAL_LOG_DATA_MIN, 'SuppLogPK': data[0][0].SUPPLEMENTAL_LOG_DATA_PK, 'SuppLogUI': data[0][0].SUPPLEMENTAL_LOG_DATA_UI, 'SuppLogFK': data[0][0].SUPPLEMENTAL_LOG_DATA_FK, 'SuppLogAll': data[0][0].SUPPLEMENTAL_LOG_DATA_ALL, 'DBUnique': data[0][0].DB_UNIQUE_NAME, 'FL': data[0][0].FORCE_LOGGING ,'DB_Param' : data[0][0].VALUE });
                        if (data[0][0].SUPPLEMENTAL_LOG_DATA_MIN != 'NO' &&   data[0][0].LOG_MODE != 'NOARCHIVELOG' &&  data[0][0].FORCE_LOGGING != 'NO' && data[0][0].VALUE != 'FALSE'){
                        getDomains();
                        }
                        console.log(self);
                        return self;
                    }
                })
            }




            self.dbsupplogDP = new ArrayDataProvider(self.dbSuppInfo, { keyAttributes: 'DBUnique' });


            self.schemaListDP = new ArrayDataProvider(self.schemaNameList, { keyAttributes: 'label' });

            self.SchemaName = ko.observable();


            self.supplogcolumnArray = [{
                headerText: 'Minimum SupplementalLog ',
                field: 'SuppLog'
            },
            {
                headerText: 'Log Mode ',
                field: 'LogMode'
            },
            {
                headerText: 'FORCE LOGGING ',
                field: 'FL'
            },
            {
                headerText: 'ENABLE_GOLDENGATE_REPLICATION ',
                field: 'DB_Param'
            },
            {
                headerText: 'PrimaryKey Log',
                field: 'SuppLogPK'
            },
            {
                headerText: 'Unique Index Log ',
                field: 'SuppLogUI'
            },
            {
                headerText: 'ForeignKey Log ',
                field: 'SuppLogFK'
            },
            {
                headerText: 'All Column Log ',
                field: 'SuppLogAll'
            },
            {
                headerText: 'DB Name ',
                field: 'DBUnique'
            },

            ];

            self.openListener = function (event) {
                oj.Router.rootInstance.go('incidents');
            };

            self.username1 = ko.observableArray([]);
            self.aliasname1 = ko.observableArray([]);
            self.domname1 = ko.observableArray([]);
            self.othdom = ko.observableArray([]);
            self.alias = ko.observable();
            self.user = ko.observable();
            self.valdom = ko.observable();
            self.uName = ko.observable();
            self.uPasswd = ko.observable();
            self.uRepPass = ko.observable();

            self.buttonValue = ko.observable("add");
            self.dombuttonValue = ko.observable("existDom");
            self.domName = ko.observable();
            self.allcols = ko.observable();
            self.schema = ko.observable();
            self.AddSuppMsg = ko.observableArray([]);


            function getDomains() {
                self.username1([]);
                self.othdom([]);
                self.aliasname1([]);
                self.domname1([]);
                self.selectedAliascategory('');
                self.selectedUsercategory('');
                $.ajax({
                    url: "http://192.168.0.11:8080/ggcredstore",
                    type: 'GET',
                    dataType: 'json',
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {
                        for (var i = 0; i < data[1].length; i++) {
                            self.othdom.push({ dom: data[1][i].value });
                        }
                        self.aliasname1(data[4]);

                        for (var i = 0; i < data[2].length; i++) {
                            self.domname1.push({ label: data[2][i], value: data[2][i] });
                        }
                        for (var i = 0; i < data[0].length; i++) {
                            self.username1.push({ label: data[0][i].alias, value: data[0][i].alias, 'children': [{ label: data[0][i].uname, value: data[0][i].uname }] });
                        }
                        console.log(self)
                        return self;
                    }
                })
            }
            self.selectedDomCategory = ko.observable();
            self.selectedAliascategory = ko.observableArray([]);
            self.selectedUsercategory = ko.observable();
            self.aliascategories = ko.observableArray([]);
            self.unamecategories = ko.observable();
            let getAliascategories = (category) => {
                let found = self.aliasname1().find(c => c.value === category);
                return found ? found.children : null;
            };
            let getUnamecategories = (category) => {
                let found = self.username1().find(c => c.value === category);
                return found ? found.children : null;
            };
            self.domSelectionChanged = (event) => {
                self.selectedAliascategory('');
                let children = getAliascategories(event.detail.value);
                self.aliascategories(children);
            };


            self.OthDomProvider = new ArrayDataProvider(self.othdom, { keyAttributes: 'value' });

            self.tranlevelVal = ko.observable('schematrandata');

            var tranlevel = [
                { value: 'schematrandata', label: 'Schema Trandata' },
                { value: 'trandata', label: 'Trandata' }
            ];

            self.tranlevelDP = new ArrayDataProvider(tranlevel, { keyAttributes: 'value' });


            self.STVal = ko.observable('');

            var STOptions = [
                { value: 'ALLCOLS', label: 'ALLCOLS' },
                { value: 'NOSCHEDULINGCOLS', label: 'NOSCHEDULINGCOLS' },
                { value: '', label: 'Default' },
            ];

            self.STOptionsDP = new ArrayDataProvider(STOptions, { keyAttributes: 'value' });



            self.currentPDB = ko.observable();
            self.suppLogSchema = function (data, event) {
                self.schemaNameList([]);
                $.ajax({
                    url: "http://192.168.0.11:8080/supplogschema",
                    type: 'POST',
                    data: JSON.stringify({
                        dbname : self.currentPDB()
                    }),
                    dataType: 'json',
                    context: self,
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {
                        for (var i = 0; i < data[0].length; i++) {
                            self.schemaNameList.push({ 'label': data[0][i].USERNAME, 'value': data[0][i].USERNAME });
                        }
                        return self;
                    }

                })
            }


            self.dbLogin = function (data, event) {
                self.AddSuppMsg([]);
                $.ajax({
                    url: "http://192.168.0.11:8080/addsupplog",
                    type: 'POST',
                    data: JSON.stringify({
                        domain : self.selectedDomCategory(),
                        alias : self.currentPDB(),
                        tranlevel : self.tranlevelVal(),
                        SchemaName : self.SchemaName(),
                        opts : self.STVal()
                    }),
                    dataType: 'json',
                    context: self,
                    error: function (e) {
                        console.log(e);
                    },
                    success: function (data) {
                        document.querySelector('#AddSuppDialog').open();
                        self.AddSuppMsg(data[0])
                        return self;
                    }

                })
            }

            self.addsuppOKClose = function (event) {
                document.querySelector('#AddSuppDialog').close();
            };

            console.log(self);
            self.connected = function () {
                if (sessionStorage.getItem("userName")==null) {
                    oj.Router.rootInstance.go('signin');
                }
                else
                {
                app.onAppSuccess();
                getDB() ;

                // Implement if needed
                self.dbSuppInfo([]);
                self.currentPDB('');

                }
            };

            /**
             * Optional ViewModel method invoked after the View is disconnected from the DOM.
             */
            self.disconnected = function () {
                // Implement if needed

            };

            /**
             * Optional ViewModel method invoked after transition to the new View is complete.
             * That includes any possible animation between the old and the new View.
             */
            self.transitionCompleted = function () {
                // Implement if needed

            };
        }

        /*
         * Returns a constructor for the ViewModel so that the ViewModel is constructed
         * each time the view is displayed.  Return an instance of the ViewModel if
         * only one instance of the ViewModel is needed.
         */
        return addsuppViewModel;
    }
);
